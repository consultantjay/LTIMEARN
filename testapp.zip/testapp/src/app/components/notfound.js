
import React from 'react';

export const NotFound = () => {
    return (
        <div className="row">
            <div className="col-xs-12">
                <h2>Not Found - 404</h2>                <p>
                    The resource you have requested not found
                </p>
            </div>
        </div>
    )
}
