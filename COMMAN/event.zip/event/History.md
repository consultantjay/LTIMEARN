# Changes

## 1.0.0 / 2012-11-24

  - Make event reducible
  - Move pipe from reducers.
  - Make event module be main.

## 0.1.0 / 2012-11-09

  - Update to new method version.

## 0.0.1 / 2012-11-03

  - Initial release
