import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class HospitalServiceService {
  
  constructor(private http : HttpClient) {}
  baseUrl:string = 'http://localhost:3000/hospital/';
  getHospitals()
  {
    return this.http.get<any>(this.baseUrl);
  }
  getDetail(Provider_ID:number):Observable<any>
  {
    return this.http.get(this.baseUrl+Provider_ID)
  }

}









