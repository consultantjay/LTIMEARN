import { Component, OnInit } from '@angular/core';
import {UserService} from "../user.service";
@Component({
  selector: 'app-listing-banner',
  templateUrl: './listing-banner.component.html',
  styleUrls: ['./listing-banner.component.css']
})
export class ListingBannerComponent implements OnInit {

 

  //users = [{"property_name":"Hello"},{"property_name":"Sangsey Valley Resort"}];
  users = [];
  constructor(private userService : UserService){}
  ngOnInit(){
    this.userService.getUsers()
    .subscribe(data =>{
      this.users = data;
    });
  }


  key : string = 'firstName'; //set default
  reverse : boolean = false;
  sort(key){
    this.key = key;
    this.reverse = !this.reverse;
  }
  p:number = 1;

}
