import { Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ContentComponent } from './content/content.component';
import { ListComponent } from './list/list.component';
import { DetailComponent } from './detail/detail.component';
export const appRoutes: Routes = [

    {
        path: 'content',
        component: ContentComponent
    },
    {
        path: 'list',
        component: ListComponent
    },
    {
        path: 'detail/:id',
        component: DetailComponent
    },
    {
        path: '',
        component: ContentComponent
    }
] 