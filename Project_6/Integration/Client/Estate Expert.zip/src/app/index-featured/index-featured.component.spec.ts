import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexFeaturedComponent } from './index-featured.component';

describe('IndexFeaturedComponent', () => {
  let component: IndexFeaturedComponent;
  let fixture: ComponentFixture<IndexFeaturedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndexFeaturedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndexFeaturedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
