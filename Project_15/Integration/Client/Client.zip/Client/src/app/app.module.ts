import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
 import {appRoutes } from './routerConfig';
 import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomebodyComponent } from './homebody/homebody.component';
import { SearchbodyComponent } from './searchbody/searchbody.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule } from '@angular/forms';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';
import { UserService } from './user.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomebodyComponent,
    SearchbodyComponent,
    ProductDetailComponent
  ],
  imports: [
    BrowserModule,
     RouterModule.forRoot(appRoutes),
     Ng2SearchPipeModule,//including into imports
    FormsModule,
    Ng2OrderModule,
    NgxPaginationModule,
    HttpClientModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
