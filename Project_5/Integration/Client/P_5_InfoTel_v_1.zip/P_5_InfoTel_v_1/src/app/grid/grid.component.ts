import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

  hotels = [];
  constructor(private userService : UserService) {}

  ngOnInit() {
    this.userService.getUser().subscribe(data=> {
      this.hotels = data;
    });
  }
key:string = 'Name';
reverse:boolean = false;
sort(key){
  this.key = key;
  this.reverse = !this.reverse;
}
p:number = 1;
}
