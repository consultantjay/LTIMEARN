/* import all required modules*/

var express=require('express');
var cors=require('cors');
var app=express();
app.use(cors());
var bodyParser=require('body-parser');
app.use(bodyParser.json());
var mongojs=require('mongojs');
var db=mongojs('pro',['rest','user']);
app.use(express.static(__dirname));
var events=require('events');
var em=new events.EventEmitter();
var fs = require('fs');


//variable to store data of logger

var msg="Directory Name: "+ __dirname + "\n" +
         "StartTimeStamp: "+(new Date(Date.now()+"\n"))+
         "File Name: "+__filename+"\n"+
         "Process Version: "+process.version+"\n"+
         "Process Time: "+process.uptime()+"\n"+
         "Memory Use: "+JSON.stringify(process.memoryUsage())+"\n";


//finction for append log data in file

         var write=function()
         {
           try{
           fs.appendFile("D:\\logFile.txt", msg+"*************************************************************"+"\n"+"\n" , function(err)
           {

           });
         }
         catch(err)
         {

         }
         };



//function to call write function

         var logger=function()
         {
           em.on('error',function(err){

            });
            em.on('event1',write);
            em.emit ('event1');
         };


//data for home page

       app.get('/home',function(req,res){
      		                    db.rest.aggregate([{$skip:101},{$limit:6}],function(err,docs){
                                          res.json(docs);
                                                       }
                                );
                                logger();
                                           }
               );


//data for landing page of search

                     app.get('/',function(req,res){
      		                    db.rest.aggregate([{$limit:100}],function(err,docs){
                                          res.json(docs);
                                                       }
                                );logger();
                                           }
               );


//data for discription(detail) page

              app.get('/:id',function(req,res){
      		          db.rest.aggregate([{$match:{"uniqueId": parseInt(req.params.id)}}],function(err,docs){
                                                 res.send(docs);
                                                       }
                                );logger();
                                           }
               );


//data to be store for contact page

             app.get('/SaveUser/:name/:subject/:email/:message',function(req,res){
      		       db.user.insert({name:req.params.name,subject:req.params.subject,email:req.params.email,msg:req.params.message},function(err,docs){
                                              res.send(docs);
                                                       }
                                );logger();
                                           }
               );


//list of all cities for particular country

             app.get('/getcity/:country',function(req,res){
      		       db.rest.find({country:req.params.country},{_id:0,city:1},function(err,docs){
                                                 res.send(docs);
                                                       }
                                );logger();
                                           }
               );



//get restaurant name  for particular country and city

		app.get('/getRest/:country/:city',function(req,res){
      		                          db.rest.find({country:req.params.country,city:req.params.city},{_id:0,name:1},function(err,docs){
                                                          res.send(docs);
                                                       }
                                );logger();
                                           }
               );


//****to get Data as according to user input

//get all data for particular country

		app.get('/getCountryData/:country',function(req,res){
      		                    db.rest.find({country:req.params.country},function(err,docs){
                                                            res.send(docs);
                                                       }
                                );logger();
                                           }
               );


//get all data for particular country and city

              app.get('/getCountryCityData/:country/:city',function(req,res){
      		                  db.rest.find({country:req.params.country,city:req.params.city},function(err,docs){
                                              res.send(docs);
                                                       }
                                );logger();
                                           }
               );



//get all data for particular country,city and restaurant


		app.get('/getCountryCityRestData/:country/:city/:rest',function(req,res){
      		 			db.rest.find({country:req.params.country,city:req.params.city,name:req.params.rest},function(err,docs){
                                            res.send(docs);
                                                       }
                                );logger();
                                           }
               );



app.listen(3000,function(){
  logger();
});
