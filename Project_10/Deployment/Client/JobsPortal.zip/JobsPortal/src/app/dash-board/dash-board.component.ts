import { Component, OnInit } from '@angular/core';

import {JobsService} from '../services/jobs.service';

import {Router} from '@angular/router';
import {Job} from '../../entities/job';
import {ViewJobComponent} from '../view-job/view-job.component';
import {Query,SubQuery,Count,Skip,Limit, Regex} from '../../entities/Query';
import {Industry} from '../../entities/Industry'
import {PaginatorComponent} from '../paginator/paginator.component';
import { Subject } from 'rxjs/internal/Subject';


/*
{
@author:Tarun Rawat,
@version:1.0.0,
@Organization:LTI,
@Description:This is component that is bind to master view page 
             This components has search and listing capabilites
                 
@DISCLAIMERupcoming version may lead to complete makeover,more queries will be added in upcoming versions

}

*/


@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.css'],
  providers:[JobsService]//telling injector to inject the jobService
})
export class DashBoardComponent implements OnInit {

private jobsService:JobsService;
private jobs:Job[]=[];//
private jobsLoaded:boolean;
private viewJobComponent:ViewJobComponent;
private selectedCity:string;
private selectedJob:Job;
private selectedCompanyName:string; //company name that is feeded by user
private selectedExperience:number;
private industries:Industry[]=[];//for industry drop down
private selectedIndustry:string;
private paginator:PaginatorComponent;//child Component
private startIndex:number;//for skip
private endIndex:number;//for limit
private recordsCount:number;
private currentPage:number;//
private totalRecordsPerPage:number;//total number of records that we will display per page
private companySuggestionList:string[]=[];

//injecting JobsSerice
  constructor(service:JobsService,private router:Router) {
let object=this;
object.jobsService=service;
object.jobsLoaded=false;
object.currentPage=1;
object.totalRecordsPerPage=5;  
}

private search(){
let object=this;
  //object.selectedCity="Ujjain"
object.jobsLoaded=false;
object.jobs=[];

if(object.selectedCity==""||object.selectedCity==undefined||object.selectedCity.trim().length==0)return;

let promise=object.jobsService.getJobsByCity(object.selectedCity);


promise.then(function(response){
//console.log(response);
let data=JSON.parse(response);
;

//console.log(data);

for(let job_ of data){
let job:Job=new Job();
job.setCompanyName(job_.company);
job.setJobtitle(job_.jobtitle);
job.setLocation(job_.joblocation_address);
job.setJobDescription(job_.jobdescription)
job.setSkills(job_.skills);
job.setJobId(job_.jobid);
object.jobs.push(job);
}


//console.log('JOb ho gya');
for(let job of object.jobs){
//console.log(job);
}

object.jobsLoaded=true;

}).catch(function(error){
object.jobsLoaded=false;
console.log(error);
object.jobs=[];
});





}


ngOnInit() {
this.getIndustry();
}


//This function will recieve pageNumber that will create startIndex and endIndex 
// and will fetch and render records per page
finalSearch(pageNumber):void{
let object=this;
var subQuery:SubQuery=new SubQuery();

object.jobs=[];

//Now we are creating dynamic query
if(!(object.selectedCompanyName==undefined||object.selectedCompanyName==null||object.selectedCompanyName.length==0)){
subQuery.company=object.selectedCompanyName;//adding company in query eg 
}
if(!(object.selectedCity==undefined||object.selectedCity==null||object.selectedCity.length==0)){
subQuery.joblocation_address=object.selectedCity; //{"joblocation_address":"Mumbai"}
}

if(!(object.selectedIndustry==undefined||object.selectedIndustry==null||object.selectedIndustry.length==0||object.selectedIndustry=="undefined")){
subQuery.industry=object.selectedIndustry;

}

var query:Query=new Query();
query.$match=subQuery;

 

let startIndex=(pageNumber-1)*object.totalRecordsPerPage;
let endIndex=object.totalRecordsPerPage;


let skip:Skip=new Skip();
skip.$skip=startIndex;

let limit:Limit=new Limit();
limit.$limit=endIndex;

//it should be noted that skip should be added to array before limit
let finalQuery=[];
 finalQuery.push(query);
finalQuery.push(skip);
 finalQuery.push(limit);

//Finally what will be some think like [{$match:{"joblocation_address":"Mumbai","industry":"IT","company":"LTI"},{$skip:0},{$limit:5}]

 console.log(JSON.stringify(finalQuery));
 
 

let promise:Promise<any>=object.jobsService.getData(finalQuery);

promise.then(function(response){

let data=JSON.parse(response);
;

//console.log(data);
//Populating Jobs Array
for(let job_ of data){
let job:Job=new Job();
job.setCompanyName(job_.company);
job.setJobtitle(job_.jobtitle);
job.setLocation(job_.joblocation_address);
job.setJobDescription(job_.jobdescription)
job.setSkills(job_.skills);
job.setJobId(job_.jobid);
job.setPayScale(job_.payrate);
job.setEducation(job_.education);
object.jobs.push(job);
}


console.log('JOb ho gya');
for(let job of object.jobs){
//console.log(job);
}

object.jobsLoaded=true;

object.paginator.setPaginator(object.currentPage);

}).catch(function(error){
  console.log(error);
})



}


public setCurrentPage(page){
  this.currentPage=page;
}

public getRecordsCount(){
  return this.recordsCount;
}


public getIndustry(){
let object=this;

var subQuery:SubQuery=new SubQuery();
subQuery._id="$industry";

var query:Query=new Query();
query.$group=subQuery;
console.log(JSON.stringify(query));

var finalQuery=[];
finalQuery.push(query);

console.log(JSON.stringify(finalQuery));

let promise:Promise<any>=object.jobsService.getIndustry(query);


promise.then(function(response){
var data=JSON.parse(response);

//console.log(data);
for(let _industry of data){
  let industry:Industry=new Industry();
  industry.name=_industry._id;
  object.industries.push(industry);
}

}).catch(function(error){
//yaha par kuch karna hai
console.log(error);
});

}

public getCompany(){
  let object=this;
  console.log(object.selectedCompanyName);
  object.companySuggestionList=[];

if(object.selectedCompanyName==undefined||object.selectedCompanyName==null||object.selectedCompanyName.length<=2)return;

let finalQuery=[];
let subQuery1:SubQuery=new SubQuery();
subQuery1._id="$company";

let chars:Regex=new Regex();
chars.$regex="^"+object.selectedCompanyName;

let subQuery2:SubQuery=new SubQuery();
subQuery2._id=chars;

let subQuery3:SubQuery=new SubQuery();
subQuery3.company=1;

let query1:Query=new Query();
query1.$group=subQuery1;
let query2:Query=new Query();
query2.$match=subQuery2;
let query3:Query=new Query();
query3.$project=subQuery3;

let query4:Query=new Query();
query4.$limit=10;

finalQuery.push(query1);
finalQuery.push(query2);
finalQuery.push(query3);
finalQuery.push(query4);

console.log(JSON.stringify(finalQuery));
let promise:Promise<any>=object.jobsService.getData(finalQuery);


promise.then(function(response){
var data=JSON.parse(response);
object.companySuggestionList=[];
for(let element of data){
  object.companySuggestionList.push(element._id);
}

}).catch(function(error){
console.log(error);
});

}

public getJobsCount(){
  let object=this;
  var subQuery:SubQuery=new SubQuery();

  object.jobs=[];

  object.currentPage=1;

  if(!(object.selectedCompanyName==undefined||object.selectedCompanyName==null||object.selectedCompanyName.length==0)){
  subQuery.company=object.selectedCompanyName;
  }
  if(!(object.selectedCity==undefined||object.selectedCity==null||object.selectedCity.length==0)){
  subQuery.joblocation_address=object.selectedCity;
  }

  if(!(object.selectedIndustry==undefined||object.selectedIndustry==null||object.selectedIndustry.length==0||object.selectedIndustry=="undefined")){
  subQuery.industry=object.selectedIndustry;

  }

  var query:Query=new Query();
  query.$match=subQuery;

var count:Count=new Count();
count.$count="Count";

   let finalQuery=[];
   finalQuery.push(query);
finalQuery.push(count);

   console.log(JSON.stringify(finalQuery));


   let promise:Promise<any>=object.jobsService.getIndustry(finalQuery);


   promise.then(function(response){

   var json=JSON.parse(response);

   if(json.length==0)
   {console.log('empty result set');
   //Yaha par ek error page btana hai
   
   return;
   }
  object.recordsCount=json[0].Count;



object.paginator.setRecordCount(object.recordsCount);
console.log('records Count '+object.recordsCount);
object.paginator.setPage(1);
object.paginator.setPaginator(object.currentPage);
   }).catch(function(error){
   //yaha par kuch karna hai
   console.log(error);
   });





}


public setPaginator(paginator){
let object=this;
object.paginator=paginator;
console.log('Setting paginator');
}

}
