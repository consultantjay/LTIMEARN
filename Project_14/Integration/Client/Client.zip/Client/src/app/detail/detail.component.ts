import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HospitalServiceService } from 'src/app/hospital-service.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  hid : number;
  details = [];

  constructor(private activateRouter:ActivatedRoute,private hospitalService:HospitalServiceService) { 
    let object = this;
    object.hid = parseInt(this.activateRouter.snapshot.paramMap.get('id'));
  }

  ngOnInit() {
    this.getHospitalDetail(this.hid);
  }
  hospitalDetails={};
  getHospitalDetail(hid:number){
    this.hospitalService.getDetail(this.hid)
    .subscribe(data=>{
      console.log(data);
      this.hospitalDetails = data[0];
      console.log(this.details);
    })
  }

}
