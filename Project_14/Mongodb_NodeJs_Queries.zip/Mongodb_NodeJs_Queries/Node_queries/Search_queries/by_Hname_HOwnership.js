// Search by Hospital name and Hospital ownership

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"Hospital Name":"ST VINCENT'S BIRMINGHAM",
		"Hospital Ownership":"Voluntary non-profit - Private"
	    },function(err,res){
				console.log(res);
			       }
           );