import { Component, OnInit } from '@angular/core';
import { HotelService } from 'src/app/services/hotel.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detailbody',
  templateUrl: './detailbody.component.html',
  styleUrls: ['./detailbody.component.css']
})
export class DetailbodyComponent implements OnInit {
  detail=[];
  private uid:string;

  constructor(private activateRouter:ActivatedRoute, private hotelService:HotelService) {
    let object=this;
    object.uid=this.activateRouter.snapshot.paramMap.get('id');
    console.log(object.uid);
   }

  ngOnInit() {
    console.log(this.uid)
    this.hotelService.getDetails(this.uid)
    .subscribe(data => {
       console.log(data);
       this.detail=data;
    })
  }

}
