import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/rest.service';


@Component({
  selector: 'app-listing-search',
  templateUrl: './listing-search.component.html',
  styleUrls: ['./listing-search.component.css']
})
export class ListingSearchComponent implements OnInit {
 
  //to storre responce
  rests=[];
  images=["res-1.jpg","res-2.jpg","res-3.jpg","res-4.jpg","res-5.jpg","res-6.jpg","res-7.jpg","res-8.jpg","res-9.jpg","res-10.jpg","res-11.jpg","res-12.jpg","res-13.jpg","res-14.jpg",
"res-15.jpg","res-15.jpg","res-17.jpg","res-18.jpg","res-19.jpg","res-20.jpg","res-21.jpg","res-22.jpg","res-23.jpg","res-24.jpg","res-25.jpg","res-26.jpg","res-27.jpg","res-28.jpg","res-29.jpg",
"res-30.jpg","res-31.jpg"];
  //for services
  constructor(private restServices:RestService) { }

  ngOnInit() {
    this.restServices.getRests()
    .subscribe(data=>{
         this.rests=data;
    });
  }


  //for paging
p:number=1;



getRandomInt(max:number) {
  // return Math.floor(Math.random() * Math.floor(max));
  return Math.floor(Math.random()*max);
}
}
