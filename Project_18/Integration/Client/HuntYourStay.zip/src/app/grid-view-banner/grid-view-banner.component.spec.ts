import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GridViewBannerComponent } from './grid-view-banner.component';

describe('GridViewBannerComponent', () => {
  let component: GridViewBannerComponent;
  let fixture: ComponentFixture<GridViewBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GridViewBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridViewBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
