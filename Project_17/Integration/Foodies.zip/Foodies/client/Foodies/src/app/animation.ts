// import the required animation functions from the angular animations module
