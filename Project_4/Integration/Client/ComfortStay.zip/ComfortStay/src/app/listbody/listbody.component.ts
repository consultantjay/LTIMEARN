import { Component, OnInit } from '@angular/core';
import { HotelService } from 'src/app/services/hotel.service';

@Component({
  selector: 'app-listbody',
  templateUrl: './listbody.component.html',
  styleUrls: ['./listbody.component.css'],

})
export class ListbodyComponent implements OnInit {
  rooms=[];
  hotels=[];
  constructor(private HotelService:HotelService){}
  ngOnInit(){
   
    this.HotelService.getHotels().subscribe(data=>{
      this.hotels=data;
    });
    
  }
/* odata=[];
  constructor(private service:HotelService) { }

  ngOnInit() {
    console.log('Hello');
   // let object=this;
      
    this.service.getHotels().subscribe(function(data){
      
    this.odata=data;  
    console.log(this.odata);
    })
  } */

}
