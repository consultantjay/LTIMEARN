var express = require('express');
var app = express();
var events=require('events');
var em=new events.EventEmitter();
var fs = require('fs');
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(express.static(__dirname));
var cors = require('cors');
app.use(cors())
var mongojs = require('mongojs');
var db = mongojs('project',['hotel','hotels_feedback']);

var msg="Directory Name: "+ __dirname + "\n" +
"StartTimeStamp: "+(new Date(Date.now()+"\n"))+
"File Name: "+__filename+"\n"+
"Process Version: "+process.version+"\n"+
"Process Time: "+process.uptime()+"\n"+
"Memory Use: "+JSON.stringify(process.memoryUsage())+"\n";
var write=function(){
  try{
    fs.appendFile("D:\\Final\\Trips\\Server\\logFile.txt", msg+"***********************************"
    +"\n"+"\n" , 
    function(err){  
    });
  }
  catch(err){}
};

var logger=function(){
  em.on('error',function(err){
  });
  em.on('event1',write);
  em.emit ('event1');
}; 

//TODO - To get all the documents from dataset
app.get('/list',function(req,res){
  db.hotel.find(function(err,docs){
  res.json(docs);})
  logger();
});

//TODO - To get documents from dataset by city 
app.get('/list/:id',function(req,res){
  db.hotel.find({"uniq_id":req.params.id},function(err,docs){
    res.json(docs);
  });
  logger();
});

//TODO - To insert firstname, lastname, email and message 
app.get('/list/insert/:firstName/:lastName/:email/:message',function(req,res){
  db.hotels_feedback.insert({"firstName":req.params.firstName,"lastName":req.params.l_name,"email":req.params.email,"message":req.params.email,"message":req.params.message},function(err,docs){
    res.json(docs);
  });
  logger();
});

//TODO - To get documents from dataset by city 
app.get('/list/:city/:area/:hotel_name',function(req,res){
  db.hotel.find({
    "city":req.params.city,"area":req.params.area,"property_name":req.params.hotel_name
  },
  function(err,docs){
    res.json(docs);
  });
  logger();
});

//TODO - To get documents from dataset by city
app.get('/list/city/:city',function(req,res){
  db.hotel.find({"city":new RegExp('^'+req.params.city,'i')},function(err,docs){
    res.json(docs);
  });
  logger();
});

//TODO - To get documents from dataset by area
app.get('/list/area/:area',function(req,res){
 db.hotel.find({"area":new RegExp('^'+req.params.area,'i')},function(err,docs){
   res.json(docs);
 });
 logger();
});

//TODO - To get documents from dataset by hotel name
app.get('/list/hotel_name/:hotel_name',function(req,res){
 db.hotel.find({
   "property_name":new RegExp('^'+req.params.hotel_name,'i')
 },
 function(err,docs){
   res.json(docs);
 });
 logger();
});

//TODO - To get documents from dataset by city and area
app.get('/list/city/:city/area/:area',function(req,res){
  db.hotel.aggregate([{$match:{
    "city":new RegExp('^'+req.params.city,'i'),"area":new RegExp('^'+req.params.area,'i')
    }}],
    function(err,docs){
      res.json(docs);
    });
    logger();
});

//TODO - To get documents from dataset by city and hotel name
app.get('/list/city/:city/hotel_name/:hotel_name',function(req,res){
  db.hotel.aggregate([{$match:{
    "city":new RegExp('^'+req.params.city,'i'),"property_name":new RegExp('^'+req.params.hotel_name,'i')
    }}],
    function(err,docs){
      res.json(docs);
    });
    logger();
});

//TODO - To get documents from dataset by hotel name and area
app.get('/list/area/:area/hotel_name/:hotel_name',function(req,res){
  db.hotel.aggregate([{$match:{
    "area":new RegExp('^'+req.params.area,'i'),"property_name":new RegExp('^'+req.params.hotel_name,'i')
    }}],
    function(err,docs){
      res.json(docs);
    });
    logger();
});

//TODO - To get documents from dataset by city, area and hotel name
app.get('/list/city/:city/area/:area/hotel_name/:hotel_name',function(req,res){
  db.hotel.aggregate([{$match:{
    "city":new RegExp('^'+req.params.city,'i'),area:new RegExp('^'+req.params.area,'i'),"property_name":new RegExp('^'+req.params.hotel_name,'i')
  }}],
  function(err,docs){
    res.json(docs);
  });
  logger();
});

app.listen(3000);
