/*const promiset1 = new Promise((resolve, reject) => {
    resolve(123);
});
promiset1.then((res) => {
    console.log('I get called:', res === 123); // I get called: true
});
promiset1.catch((err) => {
    // This is never called
}); */
//Error 
/*
const promiset2 = new Promise((resolve, reject) => {
    reject(new Error("Something awful happened"));
});
promiset2.then((res) => {
    // This is never called
});
promiset2.catch((err) => {
    console.log('I get called:', err.message); // I get called: 'Something awful happened'
}); */
//Chain-ability of Promises

// an async function to simulate loading an item from some server
function loadItem(id: number): Promise<{ id: number }> {
    return new Promise((resolve) => {
        console.log('loading item', id);
        setTimeout(() => { // simulate a server delay
            resolve({ id: id });
        }, 1000);
    });
}

// Chaining
let item1, item2;
loadItem(1)
    .then((res) => {
        item1 = res;
        return loadItem(2);
    })
    .then((res) => {
        item2 = res;
        console.log('done');
    }); // overall time will be around 2s

// Parallel
/*
Promise.all([loadItem(1), loadItem(2)])
    .then((res) => {
        [item1, item2] = res;
        console.log('done');
    }); // overall time will be around 1s
	*/
	
Promise.resolve(123)
    .then((res) => {
        console.log(res); // 123
        return 456;
    })
    .then((res) => {
        console.log(res); // 456
        return Promise.resolve(123); // Notice that we are returning a Promise
    })
    .then((res) => {
        console.log(res); // 123 : Notice that this `then` is called with the resolved value
        return 123;
    })	
	
	
	
	