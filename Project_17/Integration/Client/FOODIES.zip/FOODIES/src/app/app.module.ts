import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//importing routesConfig file
import {appRoutes} from './routerConfig'

import {RouterModule} from '@angular/router'


import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeBodyComponent } from './home-body/home-body.component';
import { ListingSearchComponent } from './listing-search/listing-search.component';
import { ContactComponent } from './contact/contact.component';
import { GalleryComponent } from './gallery/gallery.component';
import { from } from 'rxjs/internal/observable/from';
import { DiscriptionComponent } from './discription/discription.component';


//for pagination
import{NgxPaginationModule} from 'ngx-pagination'

//for service call and use
import{RestService} from './rest.service'
import {HttpClientModule} from '@angular/common/http'

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeBodyComponent,
    ListingSearchComponent,
    ContactComponent,
    GalleryComponent,
    DiscriptionComponent

  ],
  imports: [
    BrowserModule,
    //import routing file(routerConfig)
    RouterModule.forRoot(appRoutes),

    //for pagination
    NgxPaginationModule,

    HttpClientModule
    

  ],
  providers: [RestService],
  bootstrap: [AppComponent]
})
export class AppModule { }
