import { Injectable } from '@angular/core';

import {HttpClient} from '@angular/common/http'



@Injectable({
  providedIn: 'root'
})
export class FirstService {

  constructor(private http : HttpClient) { }
  baseUrl:string="http://localhost:3000/find/"
  getProduct(){
    return this.http.get<any>(this.baseUrl);
  }
  getProductById(id){
    return this.http.get<any>(this.baseUrl+id);
  }
  getProductByCategory(category){
    return this.http.get<any>(this.baseUrl+category);
  }


}
