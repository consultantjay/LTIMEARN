import React from 'react';

export class About extends React.Component{
    
    render(){
        return(
            <div className="row">
                <div className="col-xs-12 col-xs-offset-0">
                    <h2>About page</h2>
                </div>
            </div>
        );
    }
}