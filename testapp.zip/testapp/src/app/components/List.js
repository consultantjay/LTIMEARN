import React from 'react';
 
export class List extends React.Component{
    
    render(){
        
        return(
           
            <div className="row">
                <div className="col-xs-12 col-xs-offset-0">
                    <h2>List page</h2>
                </div>
            </div>
        );
    }
}