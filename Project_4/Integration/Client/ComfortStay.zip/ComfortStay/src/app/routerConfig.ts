import {Routes} from '@angular/router';
import { IndexbodyComponent } from './indexbody/indexbody.component';
import { ListbodyComponent } from './listbody/listbody.component';
import { DetailbodyComponent } from './detailbody/detailbody.component';
import { GallerybodyComponent } from './gallerybody/gallerybody.component';
import { Contact1Component } from './contact1/contact1.component';
import { Contact2Component } from './contact2/contact2.component';
import { SingleRoomComponent } from './single-room/single-room.component';
export const appRoutes: Routes=[
    {
        path:'',
        component: IndexbodyComponent
        },
    {
    path:'Home',
    component: IndexbodyComponent
    },
    {
        path:'List view',
        component:ListbodyComponent
    },
    {
        path:'Detail view/:id',
        component:DetailbodyComponent
    },
    {
        path:'Gallery',
        component:GallerybodyComponent
    },
    {
        path:'Contact1',
        component:Contact1Component
    },
    {
        path:'Contact2',
        component:Contact2Component
    },
    {
        path:'ListViewSingle',
        component: SingleRoomComponent
    }
    
]