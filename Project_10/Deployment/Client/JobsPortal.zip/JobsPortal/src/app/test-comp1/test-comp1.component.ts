
import { Component, OnInit,Input } from '@angular/core';
import {ColorDirective} from '../color.directive';

@Component({
  selector: 'app-test-comp1',
  templateUrl: './test-comp1.component.html',
  styleUrls: ['./test-comp1.component.css']
})
//This class is for testing purpose and has nothing to do with project
export class TestComp1Component implements OnInit {
@Input()
private num:number;
isloaded:boolean=false;
  constructor() {
console.log('hi');

   }

  ngOnInit() {
  }

  sam(){
    console.log('sam');
  }
  ngOnChanges(map){
    console.log(map);
  }
}
