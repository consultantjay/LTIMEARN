import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/rest.service';


@Component({
  selector: 'app-listing-search',
  templateUrl: './listing-search.component.html',
  styleUrls: ['./listing-search.component.css']
})
export class ListingSearchComponent implements OnInit {
 
  //to storre responce
  rests=[];

  //for services
  constructor(private restServices:RestService) { }

  ngOnInit() {
    this.restServices.getRests()
    .subscribe(data=>{
         this.rests=data;
    });
  }


  //for paging
p:number=1;

}
