import React from 'react';

export class Footer extends React.Component{
    
    render(){
        return(
            <div className="jumbotron">
                  <p>Footer</p>
            </div>
        );
    }
}