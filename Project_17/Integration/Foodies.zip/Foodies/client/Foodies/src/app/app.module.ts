import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//importing routesConfig file
import {appRoutes} from './routerConfig'

import {RouterModule} from '@angular/router'


import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeBodyComponent } from './home-body/home-body.component';
import { ListingSearchComponent } from './listing-search/listing-search.component';
import { ContactComponent } from './contact/contact.component';
import { GalleryComponent } from './gallery/gallery.component';

import { DiscriptionComponent } from './discription/discription.component';
//for pagination
import{NgxPaginationModule} from 'ngx-pagination'
//for service call and use
import{RestService} from './rest.service'
import {HttpClientModule} from '@angular/common/http'
//for serching
import {Ng2SearchPipeModule} from 'ng2-search-filter'
import { FormsModule } from '@angular/forms'
//for sorting
import {Ng2OrderModule}from 'ng2-order-pipe'
//for map
import { AgmCoreModule } from '@agm/core';
import {NgForm} from '@angular/forms'
//for animation
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { ToastrModule } from 'ngx-toastr';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeBodyComponent,
    ListingSearchComponent,
    ContactComponent,
    GalleryComponent,
    DiscriptionComponent,

  ],
  imports: [
    BrowserModule,
    //import routing file(routerConfig)
    RouterModule.forRoot(appRoutes),
    //for pagination
    NgxPaginationModule,
    HttpClientModule,
    BrowserAnimationsModule,
    //for sorting
    Ng2OrderModule,
    //for search
    Ng2SearchPipeModule,
    FormsModule,
     //for map
     AgmCoreModule.forRoot({
     apiKey: 'AIzaSyBxlHaX-MF1tQYJhjpk3w1aJwToJ2Di3BQ'
    }),

    ToastrModule.forRoot(  { timeOut: 2000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
    }) 
  ],
  providers: [RestService],//for service call
  bootstrap: [AppComponent]
})
export class AppModule { }
