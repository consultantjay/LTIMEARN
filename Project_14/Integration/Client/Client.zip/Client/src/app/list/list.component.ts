import { Component, OnInit } from '@angular/core';
import { HospitalServiceService } from '../hospital-service.service'

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit
{
  hospitals = [];
  
  constructor(private HospitalServiceService: HospitalServiceService){}
  ngOnInit()
  {
    this.HospitalServiceService.getHospitals()
    .subscribe(data =>{
      this.hospitals = data;
    });
  }
  images = [
    "download.jpg",
    "download1.jpg",
    "download2.jpg",
    "download3.jpg",
    "image-03.jpg",
    "image-04.jpg",
    "image-05.jpg",
    "image-06.jpg",
    "image-07.jpg",
    "image-08.jpg",
    "image-09.jpg",
    "image-10.jpg",
    "image-11.jpg",
    "image-12.jpg",
    "image-13.jpg",
    "image-14.jpg",
    "image-15.jpg"
  ];

}
