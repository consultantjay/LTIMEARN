import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FetchAllService {

  
  constructor(private http: HttpClient) { }
  
  baseUrl: string = 'http://localhost:3000/';
  getToysAll(){
    return this.http.get<any>(this.baseUrl);
   }

   getToysHomeGrid(){
    return this.http.get<any>(this.baseUrl+"home");
   }
}
