var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.json());
var mongojs = require('mongojs');
var db = mongojs('YELP',['yelp']);
app.use(express.static(__dirname));
//service call for list users
app.get('/list',function(req,res){
  console.log("Tested");
  db.yelp.find(function(err,docs){res.json(docs); })
});
app.get('/:id',function(req,res){
  console.log(req.params.id);
    db.yelp.find({"_id":parseInt(req.params.id)},function(err,docs){res.json(docs);})
});
app.listen(3000);
console.log("server Running on port 3000");
