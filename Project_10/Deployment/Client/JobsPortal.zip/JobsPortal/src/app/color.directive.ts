import { Directive } from '@angular/core';
import {ElementRef} from '@angular/core';

@Directive({
  selector: '[appColor]'
})
export class ColorDirective {

  constructor(private reference:ElementRef) {
    this.reference.nativeElement.style.backgroundColor='yellow';
   }

}
