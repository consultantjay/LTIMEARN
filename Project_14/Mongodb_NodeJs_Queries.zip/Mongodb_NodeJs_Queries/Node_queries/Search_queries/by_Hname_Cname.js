// Search by Hospital Name and City

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"Hospital Name":"HIGHLANDS MEDICAL CENTER",
		City:"SCOTTSBORO"
	    },function(err,res){
				console.log(res);
	     		       }
	   );