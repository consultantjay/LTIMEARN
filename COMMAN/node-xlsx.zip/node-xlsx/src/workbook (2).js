
export default class Workbook {
  SheetNames = [];
  Sheets = {};
}
