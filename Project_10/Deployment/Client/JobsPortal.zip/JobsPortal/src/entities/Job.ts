export class Job{
private education:string;
private companyName:string;
private location:string;
private jobtitle:string;
private jobdesc:string;
private jobid:number;
private skills:string;
private payscale:string;//String type is because we dont have exact package in database but this will be changed in 
//upcoming version 
//package is reserved keyword

setEducation(education){
this.education=education;
}

getEducation(){
  return this.education;
}
setPayScale(payscale){
  this.payscale=payscale;
}
getPayScale():string{//This funciton will be changed in upcoming versions
  return this.payscale;
}


setJobId(id){
  this.jobid=id;
}
getJobId():number{
  return this.jobid;
}

getSkills():string{
  return this.skills;
}
setSkills(skills){
  this.skills=skills;
}


setJobDescription(desc){
  this.jobdesc=desc;
}

getJobDesc():string{
  return this.jobdesc;
}

public getLocation(){
  return this.location;
}

setLocation(location){
  this.location=location;
}
  setJobtitle(jobtitle){
    this.jobtitle=jobtitle;
}
public getJobtitle(){
  return this.jobtitle;
}

public getCompanyName(){
  return this.companyName;
}
setCompanyName(name){
  this.companyName=name;
}




}
