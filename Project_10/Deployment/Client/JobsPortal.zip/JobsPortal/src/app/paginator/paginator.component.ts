import { Component, OnInit,Input } from '@angular/core';

import {DashBoardComponent} from '../dash-board/dash-board.component'



@Component({
  selector: 'app-paginator',
  templateUrl: './paginator.component.html',
  styleUrls: ['./paginator.component.css']
})
export class PaginatorComponent implements OnInit {

private dashBoard:DashBoardComponent;
private recordCount:number;
@Input()
private links:Array<number>=[];
private totalLinks:number;
private startLink:number;
private endLink:number;
private currentLink:number;
private isNextEnabled:boolean;
private isPreviousEnabled:boolean;
private totalVisibleLinks:number;
private currentPage:number;
private totalRecordsCount:number;
private isPaginatorEnabled:boolean;


  constructor() {
let object=this;
object.totalVisibleLinks=3;
object.isPaginatorEnabled=false;
object.isPreviousEnabled=false;
object.isNextEnabled=true;
   }

  ngOnInit() {
    console.log('ngOnInit');
  }

ngOnChanges(){
  console.log('ngOnChanges');
}

@Input()//getting reference of dashcomponent
public set dashBoardComponent(dashBoardComponent){
let object=this;

object.dashBoard=dashBoardComponent;
object.dashBoard.setPaginator(this);//registering paginator component to dashBoard..no both have reference of each other
//This will help us to get data easily
}

//Setting total records count
public setRecordCount(count){
  let object=this;
  object.recordCount=count;
}
//On next
public onNext(){
let object=this;
object.isPreviousEnabled=true;//enabling previous button
object.currentPage=object.endLink+1;


object.setPage(object.currentPage);
object.setPaginator(object.currentPage);

}

public onPrevious(){
  let object=this;
  object.isNextEnabled=true;//enabling next button
  object.currentPage=object.startLink-1;
  object.setPage(object.currentPage);
  object.setPaginator(object.currentPage);
  
}

public setPage(page){
  let object=this;
  object.currentPage=page;
  console.log(page);
  object.dashBoard.setCurrentPage(page); 
  object.dashBoard.finalSearch(page);
}

public setPaginator(pageNumber){
let object=this;

object.totalRecordsCount=object.dashBoard.getRecordsCount();

console.log('currentPage '+object.currentPage);

object.totalLinks=Math.ceil(object.totalRecordsCount/5);//5 is recordsPerPage

object.isNextEnabled=true;

let x:number=Math.floor((pageNumber-1)/object.totalVisibleLinks);
object.startLink=object.totalVisibleLinks*x+1;
object.endLink=object.startLink+object.totalVisibleLinks-1;

if(object.startLink==1){
  object.isPreviousEnabled=false;
}

if(object.endLink>=object.totalLinks){
  object.endLink=object.totalLinks;
  object.isNextEnabled=false;

}

object.links=[];
console.log(object.startLink,object.endLink);

for(var i=this.startLink;i<=this.endLink;i++)
{
  this.links[i-1]=i;
}

object.isPaginatorEnabled=true;


}


}
