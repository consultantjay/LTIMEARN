import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index-static',
  templateUrl: './index-static.component.html',
  styleUrls: ['./index-static.component.css']
})
export class IndexStaticComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
