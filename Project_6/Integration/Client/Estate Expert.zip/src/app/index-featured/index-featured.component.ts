import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index-featured',
  templateUrl: './index-featured.component.html',
  styleUrls: ['./index-featured.component.css']
})
export class IndexFeaturedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
