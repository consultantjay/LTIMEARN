export class Query{
$match:SubQuery;
$project:SubQuery;
$limit:any;
$group:any;
$count:any;
}

export class SubQuery{
jobid:any;
joblocation_address:any;
jobtitle:any;
skills:any;
company:any;
industry:any;
_id:any;
}

export class Regex{
$regex:any;
}

export class Count{
  $count:any;
}

export class Skip{
  $skip:any;
}

export class Limit{
  $limit:any;
}