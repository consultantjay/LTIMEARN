// Search by State and Hospital Ownership

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		State:"AZ",
		"Hospital Ownership":"Voluntary non-profit - Private"
	    },function(err,res){
				console.log(res);
			       }
           );