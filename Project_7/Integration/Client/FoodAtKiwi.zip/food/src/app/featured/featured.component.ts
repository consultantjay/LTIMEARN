import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-featured',
  templateUrl: './featured.component.html',
  styleUrls: ['./featured.component.css']
})
export class FeaturedComponent implements OnInit {
  images=["featured2.jpg","featured3.jpg","featured1.jpg","featured4.jpg","f1.jpg","a.jpg"];
  users=[];
constructor( private userService: UserService){}
ngOnInit(){
  this.userService.getFood()
  .subscribe( data =>{
    console.log(data);
  
    let index=8;

    while(index<data.length){
this.users.push(data[index++]);
    }

    
  });
}
p:number = 1;
}


  