import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';


@Injectable()
export class RestService {

  constructor(private http:HttpClient) { }
  baseUrl:string='http://localhost:3000/'
  getRests(){
    return this.http.get<any>(this.baseUrl);
  }
  getDetails(id:number)
  {
    return this.http.get<any>(this.baseUrl+id);
  }
}
