import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BodyOffersComponent } from './body-offers.component';

describe('BodyOffersComponent', () => {
  let component: BodyOffersComponent;
  let fixture: ComponentFixture<BodyOffersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BodyOffersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BodyOffersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
