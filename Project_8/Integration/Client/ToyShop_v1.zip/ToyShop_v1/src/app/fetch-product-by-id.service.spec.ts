import { TestBed, inject } from '@angular/core/testing';

import { FetchProductByIdService } from './fetch-product-by-id.service';

describe('FetchProductByIdService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FetchProductByIdService]
    });
  });

  it('should be created', inject([FetchProductByIdService], (service: FetchProductByIdService) => {
    expect(service).toBeTruthy();
  }));
});
