import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-combine',
  templateUrl: './combine.component.html',
  styleUrls: ['./combine.component.css']
})
export class CombineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
