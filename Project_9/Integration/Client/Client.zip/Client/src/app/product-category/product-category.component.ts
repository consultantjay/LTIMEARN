import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { FirstService } from 'services/first.service';

@Component({
  selector: 'app-product-category',
  templateUrl: './product-category.component.html',
  styleUrls: ['./product-category.component.css']
})
export class ProductCategoryComponent implements OnInit {

  constructor(private activatedRoute:ActivatedRoute,private _router:Router,
    private firstservice:FirstService) { }
product;
    ngOnInit(){
      this.firstservice.getProductById(this.activatedRoute.snapshot.params['category']).subscribe(data=>{
        this.product=data
        
   
      })
      
    }
}
