import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FirstService } from 'services/first.service';
import { ProductComponent } from 'src/app/product/product.component';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {

  id;
  product;
  sub
  image
  
  constructor(private activatedRoute:ActivatedRoute,private _router:Router,
    private firstservice:FirstService) { }

    ngOnInit(){
      this.firstservice.getProductById(this.activatedRoute.snapshot.params['id']).subscribe(data=>{
        this.product=data
        let index,i;
   
      })
      
    }


  }

