import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})

export class UserService {
  constructor(private http:HttpClient) { }
  baseUrl:string = "http://localhost:3000/";
  
  getUsers()
  {
    return this.http.get<any>(this.baseUrl+"getRestaurantDetails");
  }
  getPizzaDetails(restaurant_name:string):Observable<any>
  {
    return this.http.get<any>(this.baseUrl+"getPizzaDetails/"+restaurant_name);
  }
}
