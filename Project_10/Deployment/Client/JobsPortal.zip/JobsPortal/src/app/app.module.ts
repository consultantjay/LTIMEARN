import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {NgForm,FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { MapComponentComponent } from './map-component/map-component.component';
import {AgmCoreModule} from '@agm/core';
import { DashBoardComponent } from './dash-board/dash-board.component';
import {JobsService} from './services/jobs.service';
import { ViewJobComponent } from './view-job/view-job.component';

import { FileUploadService} from './services/file-upload.service';

import {Routes,RouterModule,ActivatedRoute} from '@angular/router';
import { TestComp1Component } from './test-comp1/test-comp1.component';
import { TestComp2Component } from './test-comp2/test-comp2.component';


import { PaginatorComponent } from './paginator/paginator.component';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import {HttpClientModule} from '@angular/common/http';
import { ColorDirective } from './color.directive';


const routes:Routes=[{path:'viewJob/:jobid',component:ViewJobComponent},{path:'test1',component:TestComp1Component},{path:'test2',component:TestComp2Component}];

@NgModule({
  declarations: [
    AppComponent,
    MapComponentComponent,
    DashBoardComponent,
    ViewJobComponent,
    TestComp1Component,
    TestComp2Component,
    PaginatorComponent,
    ColorDirective
  ],
  imports: [
    BrowserModule,
AgmCoreModule.forRoot({
apiKey:"AIzaSyBxlHaX-MF1tQYJhjpk3w1aJwToJ2Di3BQ"

}),
FormsModule,
RouterModule.forRoot(routes),MatButtonModule, MatCheckboxModule,HttpClientModule
  ],
  providers: [JobsService,FileUploadService],
  bootstrap: [AppComponent]
})
export class AppModule {



}
