// Sorting on the basis of Rating in ascending order

var mongojs = require('mongojs');
var db = mongojs('P',['hos']);
db.hos.aggregate([{$sort:{"Hospital overall rating":1}}],function(err,res){
				console.log(res);
	                     }
                 
		);