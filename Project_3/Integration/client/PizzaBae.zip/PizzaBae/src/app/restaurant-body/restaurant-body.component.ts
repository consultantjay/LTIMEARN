import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-restaurant-body',
  templateUrl: './restaurant-body.component.html',
  styleUrls: ['./restaurant-body.component.css']
})
export class RestaurantBodyComponent implements OnInit {

restaurants = [];

constructor(private userService:UserService){}
ngOnInit()
{
  this.userService.getUsers()
    .subscribe(data=>{
      this.restaurants=data;
    });
}
p:number=1;

// key:string = 'menus.amount';
// reverse:boolean = false;
// sort(key){
//   this.key = key;
//   this.reverse = !this.reverse;
// }

}
