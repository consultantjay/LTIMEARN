"use strict";

var method = require("method")
var send = method("send")

module.exports = send
