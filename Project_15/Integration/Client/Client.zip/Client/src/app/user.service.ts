import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { concat } from 'rxjs/internal/observable/concat';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  baseUrl:string = 'http://localhost:3000/list/';
  //TODO - Service to get all the documents from the dataset
  getList(){
    return this.http.get<any>(this.baseUrl);
  }
  //TODO - Service to get all the documents from the dataset
  getData(city:string,area:string,hotel_name:string){
    return this.http.get<any>(this.baseUrl+city+"/"+area+"/"+hotel_name);
  }
  //TODO -Service to get resorts by city
  getResortByCity(city:string){
    return this.http.get<any>(this.baseUrl+"city/"+city);
  }
  //TODO -Service to get resorts by area
  getResortByArea(area:string){
    return this.http.get<any>(this.baseUrl+"area/"+area);
  }
  //TODO -Service to get resorts by hotel name
  getResortByHotelName(hotel_name:string){
    return this.http.get<any>(this.baseUrl+"hotel_name/"+hotel_name);
  }
  //TODO -Service to get resorts by city and area
  getResortsByCityArea(city:string,area:string){
    return this.http.get<any>(this.baseUrl+"city/"+city+"/area/"+area);
  }
  //TODO -Service to get resorts by city and hotel name
  getResortsByCityHotelName(city:string,hotel_name:string){
    return this.http.get<any>(this.baseUrl+"city/"+city+"/hotel_name/"+hotel_name);
  }
  //TODO -Service to get resorts by area and hotel name
  getResortsByAreaHotelName(area:string,hotel_name:string){
    return this.http.get<any>(this.baseUrl+"area/"+area+"/hotel_name/"+hotel_name);
  }
  //TODO -Service to get resorts by city, area and hotel name
  getResortsByCityAreaHotelName(city:string,area:string,hotel_name:string){
    return this.http.get<any>(this.baseUrl+"city/"+city+"/area/"+area+"/hotel_name/"+hotel_name);
  }
  //TODO -Service to get resort by resort id
  getProductDetails(pid:string):Observable<any>{
    return this.http.get(this.baseUrl+pid);
  }
  //TODO -Submit form
  submitFormData(firstName:string,lastName:string,email:string,message:string):Observable<any>{
    return this.http.get(this.baseUrl+"insert/"+firstName+"/"+lastName+"/"+email+"/"+message);
  }
}
