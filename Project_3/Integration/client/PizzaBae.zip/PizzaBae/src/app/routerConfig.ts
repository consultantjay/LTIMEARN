import {Routes} from '@angular/router'
import {HeaderComponent} from './header/header.component';
import {FooterComponent} from './footer/footer.component';
import {IndexBodyComponent} from './index-body/index-body.component';
import {MapBodyComponent} from './map-body/map-body.component';
import {RestaurantBodyComponent} from './restaurant-body/restaurant-body.component';
import {ContactBodyComponent} from './contact-body/contact-body.component';
import {ProfileBodyComponent} from './profile-body/profile-body.component';

export const appRoutes:Routes = [
    {
        path:'index',
        component: IndexBodyComponent
    },
    {
        path:'map',
        component: MapBodyComponent 
    },
    {
        path:'restaurant',
        component: RestaurantBodyComponent 
    },
    {
        path:'contact',
        component: ContactBodyComponent 
    },
    {
        path:'profile',
        component: ProfileBodyComponent
    },
    {
        path:'profile/:restaurant_name',
        component: ProfileBodyComponent
    }
];