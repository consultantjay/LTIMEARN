import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-map-body',
  templateUrl: './map-body.component.html',
  styleUrls: ['./map-body.component.css']
})
export class MapBodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
