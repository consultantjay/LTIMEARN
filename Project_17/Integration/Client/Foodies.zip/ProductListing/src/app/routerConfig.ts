import {Routes} from '@angular/router'


import { ListingSearchComponent } from 'src/app/listing-search/listing-search.component';
import { ContactComponent } from 'src/app/contact/contact.component';
import { GalleryComponent } from 'src/app/gallery/gallery.component';
import { HomeBodyComponent } from 'src/app/home-body/home-body.component';
import { DiscriptionComponent } from 'src/app/discription/discription.component';

export const appRoutes: Routes=[
{
 path:'',
 component :HomeBodyComponent
},
{
    path:'home',
    component :HomeBodyComponent
   },
{
    path:'search',
 component :ListingSearchComponent 
},
{path:'contact',
 component :ContactComponent
},
{path:'gallery',
 component :GalleryComponent
},


{
 path:'search/describe/:id',
 component :DiscriptionComponent
},
];