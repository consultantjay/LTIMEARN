import React from 'react';

export class Home extends React.Component{
    
    render(){
        return(
            <div className="row">
                <div className="col-xs-12 col-xs-offset-0">
                    <h2>Home page</h2>
                </div>
            </div>
        );
    }
}