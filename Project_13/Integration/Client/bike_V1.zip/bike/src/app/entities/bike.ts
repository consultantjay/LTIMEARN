import { BikeService } from '../bike.service';

export class Bike
{
    private uid;
    private Make;
    private Model;
    private Price;
    private Condition;
    private Locat;
    private Model_Year;
    private Mileage;
    private Exterior_Color;
    private Warranty;
    private Sub_Model;
    private Type;
    private Feedback_Perc;
    private N_Reviews;
    private Seller_Status;

   
    setUid(uid)
    {
        this.uid=uid;
    }
    setMake(Make)
    {
        this.Make=Make;
    }
    setModel(Model)
    {
        this.Model=Model;
    }
    setPrice(Price)
    {
        this.Price=Price;
    }
    setCondition(Condition)
    {
        this.Condition=Condition;
    }
    setModel_Year(Model_Year) 
    {
        this.Model_Year=Model_Year;
    }
    setMileage(Mileage)
    {
        this.Mileage=Mileage;
    }
    setExterior_Color(Exterior_Color)
    {
        this.Exterior_Color=Exterior_Color;
    }
    setWarranty(Warranty)
    {
        this.Warranty=Warranty;
    }
    setSub_Model(Sub_Model)
    {
        this.Sub_Model=Sub_Model;
    }
    setType(Type)
    {
        this.Type=Type;
    }
    setFeedback_Perc(Feedback_Perc)
    {
        this.Feedback_Perc=Feedback_Perc;
    }
    setN_Reviews(N_Reviews)
    {
        this.N_Reviews=N_Reviews;
    }
    setSeller_Status(Seller_Status)
    {
        this.Seller_Status=Seller_Status;
    }
    setLocat(Locat)
    {
        this.Locat=Locat;
    }




    getUid()
    {
        return this.uid;
    }
    getMake()
    {
        return this.Make;
    }
    getModel()
    {
        return this.Model;
    }
    getPrice()
    {
        return this.Price;
    }
    getCondition()
    {
        return this.Condition;
    }
    getModel_Year()
    {
        return this.Model_Year
    }
    getMileage()
    {
        return this.Mileage;
    }
    getExterior_Color()
    {
        return this.Exterior_Color;
    }
    getWarranty()
    {
        return this.Warranty;
    }
    getSub_Model()
    {
        return this.Sub_Model;
    }
    getType()
    {
        return this.Type;
    }
    getFeedback_Perc()
    {
        return this.Feedback_Perc;
    }
    getN_Reviews()
    {
        return this.N_Reviews
    }
    getSeller_Status()
    {
        return this.Seller_Status;
    }
    getLocat()
    {
        return this.Locat;
    }
}