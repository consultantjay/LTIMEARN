import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallerybody',
  templateUrl: './gallerybody.component.html',
  styleUrls: ['./gallerybody.component.css']
})
export class GallerybodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
