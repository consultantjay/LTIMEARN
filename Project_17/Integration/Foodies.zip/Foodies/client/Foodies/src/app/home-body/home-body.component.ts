import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/rest.service';//import of service class

@Component({
  selector: 'app-home-body',
  templateUrl: './home-body.component.html',
  styleUrls: ['./home-body.component.css'],
})

export class HomeBodyComponent implements OnInit {
  rests=[]; //for home page data
  constructor(private restServices:RestService) { }

  ngOnInit() {
    //service call for home page data
    this.restServices.homeRests()
    .subscribe(data=>{
         this.rests=data;
       
    });
  }
}
