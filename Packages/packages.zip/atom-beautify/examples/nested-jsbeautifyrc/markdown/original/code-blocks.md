A code block with correct fences:

```js
console.log('hello world!')
```

A code block with mistyped fences:

~~~js
console.log('hello world!')
~~~

Code block with forgotten fences:

    console.log('hello world!')
