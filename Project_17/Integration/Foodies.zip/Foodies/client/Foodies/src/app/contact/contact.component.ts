import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/rest.service';
//import for toastr
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
          })


export class ContactComponent implements OnInit {
  form:NgForm;
  saveData:String;
  name:string;
  email:string;
  message:string;
  subject:string;
  constructor(private restServices:RestService,private toastr: ToastrService) { }
  ngOnInit() {
  }
  //code to save user data
  onSave = function(form:NgForm) {   
                      if(form.value.name===""||form.value.subject===""
                         ||form.value.email===""||form.value.message===""){
                                                        this.saveData="Please fill required data.."
                                                                         }
                      else{
                          this.restServices.saveUser(form.value.name,form.value.subject,form.value.email,form.value.message)  
                                                         .subscribe(data =>{  
                                                                         this.saveData=data;
                                                                         this.name="";
                                                                         this.email="";
                                                                         this.message="";
                                                                         this.subject=""; 
                                                                         this.saveData="Message sended.." 
                                                                         this.showSuccess();
                                                                           } 
                                                                    );  
                          }
                               } 
                    showSuccess() {
                                this.toastr.success(""+this.saveData);
                              }             
 
     }
  
 





