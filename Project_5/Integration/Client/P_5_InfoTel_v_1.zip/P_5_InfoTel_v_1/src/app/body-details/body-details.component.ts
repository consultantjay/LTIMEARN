import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-body-details',
  templateUrl: './body-details.component.html',
  styleUrls: ['./body-details.component.css']
})
export class BodyDetailsComponent implements OnInit {
   
      detail={};
      private id:number;
      constructor(private activateRouter : ActivatedRoute,private userService:UserService){
        let object=this;
        object.id=parseInt(this.activateRouter.snapshot.paramMap.get('id'));
        
      }

  ngOnInit() {

    this.userService.getDetails(this.id)
    .subscribe(data=>{
      this.detail=data[0];
      console.log(data);
    })
  }
p:number=1;
}
