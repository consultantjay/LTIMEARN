import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';


@Component({
  selector: 'app-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.css']
})
export class ListingComponent implements OnInit {
  images=["q1.jpg","q2.jpg","q3.jpg","q4.jpg","h2.jpg","q5.jpg","q6.jpg","q7.jpg","q8.jpg","featured2.jpg","featured3.jpg","featured1.jpg","featured4.jpg","f1.jpg","a.jpg"];
  users=[];
constructor( private userService: UserService){}
ngOnInit(){
  this.userService.getFood()
  .subscribe( data =>{
    this.users = data;
  });
}
p:number = 1;
i:number=0;
getRandomInt(max){
  return Math.floor(Math.random()*Math.floor(max));
}
}
