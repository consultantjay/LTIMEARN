import { Component, OnInit } from '@angular/core';
import { FirstService } from 'services/first.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private firstservice:FirstService){}
  product=[];
  ngOnInit(){
    this.firstservice.getProduct().subscribe(data=>{
      this.product=data
    })
  }
}
