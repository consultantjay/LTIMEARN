// Search by City name


var mongojs = require('mongojs');
var db = mongojs('P',['hos']);
db.hos.find({
		City:"EUFAULA"
	    },
            function(err,res){
				console.log(res);
	                     }
           );