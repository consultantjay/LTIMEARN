// Search by Keyword for Hospital Name


var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"Hospital Name":/.*medical center.*/gi
	    },function(err,res){
				console.log(res);
			       }
           );