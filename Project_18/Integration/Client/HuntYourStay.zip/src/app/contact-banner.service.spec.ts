import { TestBed, inject } from '@angular/core/testing';

import { ContactBannerService } from './contact-banner.service';

describe('ContactBannerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ContactBannerService]
    });
  });

  it('should be created', inject([ContactBannerService], (service: ContactBannerService) => {
    expect(service).toBeTruthy();
  }));
});
