import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantBodyComponent } from './restaurant-body.component';

describe('RestaurantBodyComponent', () => {
  let component: RestaurantBodyComponent;
  let fixture: ComponentFixture<RestaurantBodyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantBodyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantBodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
