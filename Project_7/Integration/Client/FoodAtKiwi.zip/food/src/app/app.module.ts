import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { appRoutes } from './routerConfig';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { FeaturedComponent } from './featured/featured.component';
import{ListingComponent} from './listing/listing.component';
import{AboutComponent} from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { DetailComponent } from './detail/detail.component';
import{UserService} from "./user.service";
import{HttpClientModule} from "@angular/common/http";
import{NgxPaginationModule} from 'ngx-pagination';
import { ListviewComponent } from './listview/listview.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    FeaturedComponent,
    ListingComponent,
   AboutComponent,
   ContactComponent,
   AboutusComponent,
  
   DetailComponent,
  
   ListviewComponent   
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
    NgxPaginationModule
    
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
