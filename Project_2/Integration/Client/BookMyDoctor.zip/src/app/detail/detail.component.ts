import { Component, OnInit } from '@angular/core';
import { UserService} from 'src/app/user.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  detail=[];
  private uid:number;
  
  constructor(private activateRouter:ActivatedRoute,private userService:UserService) {
    let object=this;
    object.uid = parseInt(this.activateRouter.snapshot.paramMap.get('sno'));
   }

  ngOnInit() {
    this.userService.getDetail(this.uid)
      .subscribe(data=>{
      console.log(data); 
      this.detail=data;
      console.log(this.detail);
  })
  }

}
