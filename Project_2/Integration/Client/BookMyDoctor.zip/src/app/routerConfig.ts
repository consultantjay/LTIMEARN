import {Routes} from '@angular/router';
import {BannerComponent} from './banner/banner.component';
import {InfoComponent} from './info/info.component';
import {DetailComponent} from './detail/detail.component';

export const appRoutes: Routes = [
    { path:'',
    component: BannerComponent    
},
    { path:'home',
        component: BannerComponent    
},
{
    path:'explore',
    component: InfoComponent
},
{
    path:'detail',
    component: DetailComponent
},
{
    path:'detail/:sno',
    component: DetailComponent
}

];