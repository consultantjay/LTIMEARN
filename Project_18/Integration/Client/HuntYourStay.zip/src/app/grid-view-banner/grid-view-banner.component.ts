import { Component, OnInit } from '@angular/core';
import {UserService} from "../user.service";
@Component({
  selector: 'app-grid-view-banner',
  templateUrl: './grid-view-banner.component.html',
  styleUrls: ['./grid-view-banner.component.css']
})
export class GridViewBannerComponent implements OnInit {

  users = [];
  constructor(private userService : UserService){}
  ngOnInit(){
    this.userService.getUsers()
    .subscribe(data =>{
      this.users = data;
    });
  }
  
  key : string = 'firstName'; //set default
  reverse : boolean = false;
  sort(key){
    this.key = key;
    this.reverse = !this.reverse;
  }
  p:number = 1;

}