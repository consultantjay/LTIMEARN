import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/rest.service';
import { ActivatedRoute } from '@angular/router';

@Component({
          selector: 'app-discription',
          templateUrl: './discription.component.html',
          styleUrls: ['./discription.component.css']
          })

export class DiscriptionComponent implements OnInit {
           private uid:number;
           detail=[];//for store  details of  page
           constructor(private activateRouter:ActivatedRoute,private restService:RestService) { 
                            let object=this;
                            object.uid=parseInt(this.activateRouter.snapshot.paramMap.get('id')); 
                            }        
ngOnInit(){
         //service call for details page data
         this.restService.getDetails(this.uid)
         .subscribe(data=>{
          this.detail=data;
                         })
         }
    
         p:number=1; //variable for paging 
}
