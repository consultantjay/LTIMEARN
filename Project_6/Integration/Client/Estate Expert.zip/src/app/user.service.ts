import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserService {

  constructor(private http:HttpClient) { }
  baseUrl: string = 'http://localhost:3001/displayAll/';
  getUsers(){
    return this.http.get<any>(this.baseUrl);
  }
  getDetails(id:number)
  {
    return this.http.get<any>(this.baseUrl+id);
  }
}
