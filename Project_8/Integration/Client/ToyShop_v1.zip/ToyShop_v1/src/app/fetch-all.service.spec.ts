import { TestBed, inject } from '@angular/core/testing';

import { FetchAllService } from './fetch-all.service';

describe('FetchAllService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FetchAllService]
    });
  });

  it('should be created', inject([FetchAllService], (service: FetchAllService) => {
    expect(service).toBeTruthy();
  }));
});
