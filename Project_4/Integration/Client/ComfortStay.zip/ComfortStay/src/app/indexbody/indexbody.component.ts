import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indexbody',
  templateUrl: './indexbody.component.html',
  styleUrls: ['./indexbody.component.css']
})
export class IndexbodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
