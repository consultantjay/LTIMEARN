import {Routes} from '@angular/router';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HomebodyComponent } from './homebody/homebody.component';
import { DetailsComponent } from './details/details.component';
import { ListComponent } from './list/list.component';

export const appRoutes:Routes=[
    { 
        path:'header',
        component: HeaderComponent
    },
    { 
        path:'footer',
        component: FooterComponent
    },
    { 
        path:'sidebar',
        component: SidebarComponent
    },
    { 
        path:'details/:uid',
        component: DetailsComponent
    },
    { 
        path:'',
        component: HomebodyComponent
    },
    { 
        path:'list',
        component: ListComponent
    }
];