import { Injectable } from '@angular/core';
import * as crypto from "crypto-js";
/*
@Author:Tarun Rawat
@Version:1.0.0
@Description:This service is main service which fetch data according to component need.
             This service uses promises to fetch data   
@Disclaimer:This service may have function that are deprecated and are no longer used
*/



@Injectable({
  providedIn: 'root'
})
export class JobsService {

  constructor() { }

  getJobsByCity(city):Promise<any>{
let object=this;
let url='/JobsPortal';
  let  assurance:Promise<any>=new Promise(function(resolve,reject){
    let request=new XMLHttpRequest();

    request.onload=function(){
    if(request.status==200)
    {
    resolve(request.response);
    }else{
    reject(new Error(request.statusText));
    }
    };
    request.onerror=function(){
    reject(new Error("Request error "+request.statusText));
  }


  url+='/getByCompany?'+'name='+city
  console.log(url);
    request.open("GET",url);
    request.send();
    });
    return assurance;



  }


  public getJobById(id):Promise<any>{
    let object=this;
    let url='/JobsPortal';
      let  assurance:Promise<any>=new Promise(function(resolve,reject){
        let request=new XMLHttpRequest();

        request.onload=function(){
        if(request.status==200)
        {
        resolve(request.response);
        }else{
        reject(new Error(request.statusText));
        }
        };
        request.onerror=function(){
        reject(new Error("Request error "+request.statusText));
      }


      url+='/getById?'+'jobid='+id;
      console.log(url);
        request.open("GET",url);
        request.send();
        });
        return assurance;




  }


public getIndustry(json){
  let object=this;
  let url='/JobsPortal';
    let  assurance:Promise<any>=new Promise(function(resolve,reject){
      let request=new XMLHttpRequest();

      request.onload=function(){
      if(request.status==200)
      {
      resolve(request.response);
      }else{
      reject(new Error(request.statusText));
      }
      };
      request.onerror=function(){
      reject(new Error("Request error "+request.statusText));
    }

console.log(json);

    console.log(url);
      request.open("POST",url);//sending POST request
      request.send(JSON.stringify(json));
      });
      return assurance;




}
//main service function to get data
public getData(json){
  let object=this;
  let url='/JobsPortal';
    let  assurance:Promise<any>=new Promise(function(resolve,reject){
      let request=new XMLHttpRequest();

      request.onload=function(){
      if(request.status==200)
      {
      resolve(request.response);
      }else{
      reject(new Error(request.statusText));
      }
      };
      request.onerror=function(){
      reject(new Error("Request error "+request.statusText));
    }

console.log(json);

    console.log(url);
      request.open("POST",url);
      request.send(JSON.stringify(json));
      });
      return assurance;




}



public encrypt(){

  //var mykey = crypto.RC4('aes-128-cbc', 'mypassword');
}
}
