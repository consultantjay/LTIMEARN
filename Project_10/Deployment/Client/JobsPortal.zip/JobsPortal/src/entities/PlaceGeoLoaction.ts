export class PlaceGeoLocation{
place:string;
lat:number;
long:number;
}