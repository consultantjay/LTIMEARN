import { Component, OnInit } from '@angular/core';
import { FetchAllService } from "../fetch-all.service"
import { Router, ActivatedRoute} from "@angular/router"

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {

  toysAll = [];
  constructor(private fetchAllService : FetchAllService, private router: Router){

  }

  ngOnInit(){
    console.log("shop.component.ts")
    this.fetchAllService.getToysAll()
    .subscribe(data=>{
      this.toysAll = data
    })
  }

  getToyById(uniq_id){
      console.log("->>"+uniq_id)
      this.router.navigate(['/productDetails',uniq_id])
  }

  p:number = 1;

}
