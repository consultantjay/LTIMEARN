import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {appRoutes} from './routerConfig';
import {RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { IndexbodyComponent } from './indexbody/indexbody.component';
import { ListbodyComponent } from './listbody/listbody.component';
import { DetailbodyComponent } from './detailbody/detailbody.component';
import { GallerybodyComponent } from './gallerybody/gallerybody.component';
import { Contact1Component } from './contact1/contact1.component';
import { Contact2Component } from './contact2/contact2.component';
import {HttpClientModule} from "@angular/common/http"
import {NgxPaginationModule} from 'ngx-pagination'
import { HotelService } from './services/hotel.service';
import { SingleRoomComponent } from './single-room/single-room.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    IndexbodyComponent,
    ListbodyComponent,
    DetailbodyComponent,
    GallerybodyComponent,
    Contact1Component,
    Contact2Component,
    SingleRoomComponent,

  ],
  imports: [
    BrowserModule,RouterModule.forRoot(appRoutes),HttpClientModule,NgxPaginationModule

  ],
  providers: [HotelService],
  bootstrap: [AppComponent]
})
export class AppModule { }
