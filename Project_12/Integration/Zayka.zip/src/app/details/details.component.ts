import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
    userImg: string;
    myLists = [];

  constructor(private dataService:DataService,private activeRoute: ActivatedRoute) {
    this.userImg = '/assets/images/user.png';
  }

  ngOnInit() {
    this.myLists = [];
    this.setDetails();
    this.fetchDetails();
  }

  fetchDetails() {
    let object=this;
  let address = this.activeRoute.snapshot.paramMap.get('address');
  	this.dataService.getRestsaddr(address)
      		.subscribe(
		            data => {
		            	this.myLists = data.data[0];
                  console.log(data);
		            }
		        );
  }


  public setDetails(){


    //console.log(address);
  }

}
