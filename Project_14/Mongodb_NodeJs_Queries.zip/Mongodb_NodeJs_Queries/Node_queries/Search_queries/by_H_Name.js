// Search by Hospital Name

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"Hospital Name":"CLAY COUNTY HOSPITAL"
            },function(err,res){
				console.log(res);
			       }
	   );