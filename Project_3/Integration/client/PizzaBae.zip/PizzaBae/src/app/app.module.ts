import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { appRoutes } from './routerConfig';
import { RouterModule } from '@angular/router';
import { IndexBodyComponent } from './index-body/index-body.component';
import { MapBodyComponent } from './map-body/map-body.component';
import { RestaurantBodyComponent } from './restaurant-body/restaurant-body.component';
import { ContactBodyComponent } from './contact-body/contact-body.component';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule } from '@angular/forms';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { ProfileBodyComponent } from './profile-body/profile-body.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    IndexBodyComponent,
    MapBodyComponent,
    RestaurantBodyComponent,
    ContactBodyComponent,
    ProfileBodyComponent,
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    FormsModule,
    Ng2OrderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
