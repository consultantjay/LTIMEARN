import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {
  users=[];
  constructor( private userService: UserService){}
  ngOnInit(){
    this.userService.getFood()
    .subscribe( data =>{
      console.log(data);
    
      let index=11;
  
      while(index<data.length){
  this.users.push(data[index++]);
      }
  
      
    });
  }
  p:number = 1;
  }
  
  
    