// Search by Hospital name , city, State and Hospital ownership

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"Hospital Name":"ROBERT WOOD JOHNSON UNIVERSITY HOSPITAL HAMILTON",
		"City":"HAMILTON",
		State:"NJ",
		"Hospital Ownership":"Voluntary non-profit - Private"
	    },function(err,res){
				console.log(res);
			       }
           );