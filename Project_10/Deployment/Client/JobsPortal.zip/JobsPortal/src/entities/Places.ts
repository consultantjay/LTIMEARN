export class Place{
public location:string;
}