import { BrowserModule } from '@angular/platform-browser';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { HeaderComponent } from 'src/app/header/header.component';
import { RouterModule } from '@angular/router';
import { appRoutes } from '../routerConfig';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule } from '@angular/forms';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';
import { HttpClientModule } from '@angular/common/http';
import { AgmCoreModule } from '@agm/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { HomebodyComponent } from '../homebody/homebody.component'
import { SearchbodyComponent } from 'src/app/searchbody/searchbody.component';
import { AppComponent } from 'src/app/app.component';
import { FooterComponent } from 'Resort_old/src/app/footer/footer.component';
import { ProductDetailComponent } from 'src/app/product-detail/product-detail.component';

describe('SearchbodyComponent', () => {
  let component: SearchbodyComponent;
  let fixture: ComponentFixture<SearchbodyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [  AppComponent,
        HeaderComponent,
        FooterComponent,
        HomebodyComponent,
        SearchbodyComponent,
        ProductDetailComponent],
        
      imports:[BrowserModule,
        RouterModule.forRoot(appRoutes),
        Ng2SearchPipeModule,//including into imports
          FormsModule,
          Ng2OrderModule,
          NgxPaginationModule,
          HttpClientModule,
          ReactiveFormsModule,
          ToastrModule.forRoot({ timeOut: 10000,
         positionClass: 'toast-top-full-width',
         preventDuplicates: true,}
       ),
       BrowserAnimationsModule,
       AgmCoreModule.forRoot({
         apiKey: 'AIzaSyBxlHaX-MF1tQYJhjpk3w1aJwToJ2Di3BQ'}
       )]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchbodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
