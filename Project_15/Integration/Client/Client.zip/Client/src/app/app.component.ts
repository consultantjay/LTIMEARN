import { Component } from '@angular/core';
import{ UserService } from './user.service'
import {trigger, state,style,animate,transition,query} from '@angular/animations';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('routerAnimation', [
      transition('* <=> *', [
        // Initial state of new route
        query(':enter',
          style({
            position: 'absolute',
            width:'100%',
            transform: 'translateX(-100%)'
          }),
          {optional:true}),

        // move page off screen right on leave
        query(':leave',
          animate('1200ms ease-in-out',
            style({
              position: 'absolute',
              width:'100%',
              transform: 'translateX(100%)'
            })
          ),
        {optional:true}),

        // move page in screen from left to right
        query(':enter',
          animate('1200ms ease-in-out',
            style({
              opacity: 1,
              transform: 'translateX(60%)'
            })
          ),
        {optional:true}),
      ])
    ])
  ]
})
export class AppComponent {
  title = 'app';
  getRouteAnimation(outlet) {
    return outlet.activatedRouteData.animation
  }
  
}
