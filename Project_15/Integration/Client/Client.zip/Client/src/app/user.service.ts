import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  baseUrl:string = 'http://localhost:3000/list/';
  getUsers(){
    return this.http.get<any>(this.baseUrl);
  }
  getProductDetails(pid:string):Observable<any>
  {
    return this.http.get(this.baseUrl+pid);
  }
}
