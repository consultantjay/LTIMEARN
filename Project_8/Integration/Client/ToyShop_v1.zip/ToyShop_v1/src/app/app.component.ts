import { Component } from '@angular/core';
import { FetchAllService } from "./fetch-all.service"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  toysAll = [];
  constructor(private fetchAllService : FetchAllService){}
  ngOnInit(){
    this.fetchAllService.getToysAll()
    .subscribe(data=>{
      this.toysAll = data
    })
  }

  p:number = 1;
}
