import { Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomebodyComponent } from './homebody/homebody.component';
import { SearchbodyComponent } from './searchbody/searchbody.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
export const appRoutes: Routes = [
  //TODO - Home Page
  { path:'',
    component:HomebodyComponent ,
    data: { animation: 'tiger' }
  },
  //TODO - Home Page
  { path:'home',
    component:HomebodyComponent ,
    data: { animation: 'tiger' }
  },
  //TODO - Listing Page
  { path:'search',
    component:SearchbodyComponent ,
    data: { animation: 'dolphin' }
  },
  //TODO - Header
  { path:'header',
  component:HeaderComponent 
  },
  //TODO - Footer
  { path:'footer',
  component:FooterComponent 
  },
  //TODO - Product detail Page
  { path:'details/:pid/:image_id',
  component:ProductDetailComponent ,
  data: { animation: 'dolphin' }
  },
]; 