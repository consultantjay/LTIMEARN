import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  users=[];
  constructor(private userService: UserService) { }

  ngOnInit() {

    this.userService.getUsers()
    .subscribe(data => {
      this.users = data;
    });
  }
  p:number=1;
}