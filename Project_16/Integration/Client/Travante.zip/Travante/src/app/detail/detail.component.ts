import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
detail=[];
private uid:number;
  constructor(private activateRouter : ActivatedRoute,private userService:UserService) { 

    let object=this;
    object.uid=parseInt(this.activateRouter.snapshot.paramMap.get('id'));
    console.log(object.uid);
  }

  ngOnInit() {

    this.userService.getDetails(this.uid)
    .subscribe(data=>{
      this.detail=data;
    })

  }
p:number=1;
}
