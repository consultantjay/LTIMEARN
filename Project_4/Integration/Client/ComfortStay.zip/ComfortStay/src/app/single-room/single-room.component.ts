import { Component, OnInit } from '@angular/core';
import { HotelService } from '../services/hotel.service';

@Component({
  selector: 'app-single-room',
  templateUrl: './single-room.component.html',
  styleUrls: ['./single-room.component.css']
})
export class SingleRoomComponent implements OnInit {

singleRoom = [];

  constructor(private hotelService:HotelService) { }

  ngOnInit() {
    this.hotelService.getSingleRoomDetails().subscribe(data=>{
      this.singleRoom=data;
    });
  }

}
