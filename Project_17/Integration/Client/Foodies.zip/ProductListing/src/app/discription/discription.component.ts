import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/rest.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-discription',
  templateUrl: './discription.component.html',
  styleUrls: ['./discription.component.css']
})
export class DiscriptionComponent implements OnInit {
       detail=[];
       private uid:number;
  constructor(private activateRouter:ActivatedRoute,private restService:RestService) { 

    let object=this;
    object.uid=parseInt(this.activateRouter.snapshot.paramMap.get('id'));
    console.log(object.uid);
  }
          
   ngOnInit() {
    //console.log(this.uid)
     this.restService.getDetails(this.uid)
     .subscribe(data=>{
       //console.log(data);
       this.detail=data;
     })
  
  }
  p:number=1; 
}
