import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-banner',
  templateUrl: './contact-banner.component.html',
  styleUrls: ['./contact-banner.component.css']
})
export class ContactBannerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
