// Search by Hospital name , city and Hospital ownership

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"Hospital Name":"ROBERT WOOD JOHNSON UNIVERSITY HOSPITAL HAMILTON",
		"City":"HAMILTON",
		"Hospital Ownership":"Voluntary non-profit - Private"
	    },function(err,res){
				console.log(res);
			       }
           );