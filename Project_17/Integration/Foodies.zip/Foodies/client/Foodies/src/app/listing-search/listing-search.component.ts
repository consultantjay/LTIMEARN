import { Component, OnInit } from '@angular/core';
import { RestService } from 'src/app/rest.service';//service class


@Component({
  selector: 'app-listing-search',
  templateUrl: './listing-search.component.html',
  styleUrls: ['./listing-search.component.css'],
})
export class ListingSearchComponent implements OnInit {
  rests=[];            //for listing data
  restsLength:number;  //count no. of data in response
 
  cities=[];           //cities for particular country
  rest=[];            //restaurant for particular country and city

  selectedCountry:string;    //selected country from input(dropdouwn)
  selectedCity:string;       //selected city from input(dropdouwn)
  selectedRestaurant:string; //selected restaurant from input(dropdouwn)
  
  constructor(private restServices:RestService) { }
     ngOnInit() {
                 this.restServices.getRests()
                 .subscribe(data=>{
                                   this.rests=data;
                                  this.restsLength=this.rests.length;
                                  }     
                            );
                }
   


  //images name for restaurant
  images=["res-1.jpg","res-2.jpg","res-3.jpg","res-4.jpg","res-5.jpg","res-6.jpg","res-7.jpg","res-8.jpg","res-9.jpg","res-10.jpg","res-11.jpg","res-12.jpg","res-13.jpg","res-14.jpg",
          "res-15.jpg","res-16.jpg","res-17.jpg","res-18.jpg","res-19.jpg","res-20.jpg","res-21.jpg","res-22.jpg","res-23.jpg","res-24.jpg","res-25.jpg","res-26.jpg","res-27.jpg","res-28.jpg","res-29.jpg",
          "res-30.jpg","res-31.jpg"];


 //for paging
  p:number=1;

 //function to select random number for images
getRandomInt(max) {
                 return Math.floor(Math.random() * Math.floor(max));
                    }

//function for call service for only input of country name and return name of cities
changeCountry(args){ 
                 this.selectedCountry=args.target.value;
                 this.restServices.getCity(args.target.value)
                 .subscribe(data=>{
                                  this.cities=data;    
                                   }
                            );
                this.rest=[];
                this.selectedCity="";
                this.selectedRestaurant="";
                   } 


 /*function for call service for  input of country name and city name and return
    name of restaurants*/
changeCity(args){ 
                this.selectedCity=args.target.value;
                this.restServices.getRest(this.selectedCountry,this.selectedCity)
                .subscribe(data=>{
                                 this.rest=data;     
                                }
                          );
               this.selectedRestaurant="";
                }

//take name of restaurant from input (dropdown)
changeRestaurant(args){
                      this.selectedRestaurant=args.target.value;
                      }



//event for search button
searchData(){
            if((this.selectedCity===""||this.selectedCity==="Select City") && (this.selectedRestaurant===""||this.selectedRestaurant==="Select Restaurant" ))
            {
            this.restServices.getCountryData(this.selectedCountry)
             .subscribe(data=>{
             this.rests=data;
             this.restsLength=this.rests.length;        
                              }
                        ); 
            } //serice call for data of paricular country name
            else if(this.selectedRestaurant===""){
                                                 this.restServices.getCountryCityData(this.selectedCountry,this.selectedCity)
                                                 .subscribe(data=>{
                                                                  this.rests=data;
                                                                  this.restsLength=this.rests.length;   
                                                                  }
                                                           );
                  }//service call for both country and city name
            else if((this.selectedCity!="") && (this.selectedRestaurant!="")&&(this.selectedCountry!="")){
                                          this.restServices.getCountryCityRestData(this.selectedCountry,this.selectedCity,this.selectedRestaurant)
                                                    .subscribe(data=>{
                                                                      this.rests=data;
                                                                      this.restsLength=this.rests.length;
                                                                     }
                                                              );
                    }//service call for country,city,restaurant name  all
            else{  
                this.restServices.getRests()
               .subscribe(data=>{
                 this.rests=data;
                 this.restsLength=this.rests.length;
                               }
                        );
                 }



    //fix data to empty
    //this.selectedCountry="";
    //this.selectedCity="";
    //this.selectedRestaurant="";
     //fix array of city and restaurant to empty
    //this.cities=[];
    //this.rest=[];

         }


//for sorting according to rating
Key:string='';
reverse:boolean=false;
sort(Key){
         this.Key=Key;
         this.reverse=!this.reverse;
         }




}

