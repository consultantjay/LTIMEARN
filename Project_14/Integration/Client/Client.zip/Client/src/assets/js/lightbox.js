var el = document.getElementById('clickme');
	
	

 		el.addEventListener('click', function()
		{
            		document.getElementById('lightbox').className = 'open';
        	});



var el1 = document.getElementById('close');
	
		el1.addEventListener('click', function(){
            	document.getElementById('lightbox').className = '';
        	});
	

var el2 = document.getElementById('lightbox')
	
		el2.addEventListener('click', function(e){
            	if(e.target.id == 'lightbox'){
                document.getElementById('lightbox').className = '';
            	}
        	});
	

