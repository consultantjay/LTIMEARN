import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-listview',
  templateUrl: './listview.component.html',
  styleUrls: ['./listview.component.css']
})
export class ListviewComponent implements OnInit {

  users=[];
  constructor( private userService: UserService){}
  ngOnInit(){
    this.userService.getFood()
    .subscribe( data =>{
      this.users = data;
    });
  }
  p:number=1;
}
