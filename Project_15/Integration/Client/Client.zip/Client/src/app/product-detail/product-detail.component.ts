import { Component, OnInit } from '@angular/core';
import{ UserService } from '../user.service';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { ToastrService,ToastContainerDirective } from 'ngx-toastr';
import {trigger, state,style,animate,transition,query} from '@angular/animations';
@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  constructor(private productdetailservice:UserService,private activatedRoute:ActivatedRoute,private toastr: ToastrService) { 
    let object=this;
    object.pid=this.activatedRoute.snapshot.paramMap.get('pid');
    object.image_id=parseInt(this.activatedRoute.snapshot.paramMap.get('image_id'));
  }
  ngOnInit() {
    this.getProductPage(this.pid);
    window.scrollTo(0, 0)
  }
  //TODO- Declaration of varaibles
  formdata:string;
  lastName:string;
  email:string;
  firstName:string;
  message:string;
  pid : string;
  image_id : number;
  
  //TODO -Feedback Function
  saveData(form:NgForm){
    this.firstName= form.value.firstName;
    this.lastName= form.value.lastName;
    this.email= form.value.email;
    this.message= form.value.comments;
    this.formdata= form.value.firstName+" "+form.value.lastName+" "+form.value.email+" "+form.value.message;
    this.productdetailservice.submitFormData(this.firstName,this.lastName,this.email,this.message)
    .subscribe(data => { 
      this.formdata = data;
    });
    this.firstName=""
    this.lastName=""
    this.email=""
    this.message=""
    this.toastr.success('Form Submitted Successfully!', 'Thankyou For Your Response!');
    }
  //TODO - Array of images
  images = [
    'single.png',
    'blog_01.png',
    'blog_02.png',
    'blog_03.png',
    'blog_04.png',
    'banner.jpg'
  ] ;
  //Object
  productDetails = {};
  
  //TODO - Method to get resort id
  getProductPage(pid:string){ 
    this.productdetailservice.getProductDetails(this.pid)
    .subscribe(data => { 
      this.productDetails = data[0];
    });
  }
  //TODO- Animation through angular
  getRouteAnimation(outlet) {
    return outlet.activatedRouteData.animation
  }
}
