import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body-index',
  templateUrl: './body-index.component.html',
  styleUrls: ['./body-index.component.css']
})
export class BodyIndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
