import { Routes } from '@angular/router';
import {HeaderComponent} from './header/header.component';
import {FooterComponent} from './footer/footer.component';
import {ListingBannerComponent} from './listing-banner/listing-banner.component';
import {GridViewBannerComponent} from './grid-view-banner/grid-view-banner.component';
import {HomeBannerComponent} from './home-banner/home-banner.component';
import {AboutBannerComponent} from './about-banner/about-banner.component';
import {ContactBannerComponent} from './contact-banner/contact-banner.component';
import {DetailBannerComponent} from './detail-banner/detail-banner.component';
export const appRoutes : Routes = [
    {
        path : 'Home', 
        component : HomeBannerComponent
    },
    {
        path : 'ListView', 
        component : ListingBannerComponent
    },
    {
        path : 'GridView', 
        component : GridViewBannerComponent
    },
    {
        path : 'About', 
        component : AboutBannerComponent
    }
    ,
    {
        path : 'Contact', 
        component : ContactBannerComponent
    },
     {
        path : '', 
        component : HomeBannerComponent
    },
    {
        path : 'DetailView/:uniq_id', 
        component : DetailBannerComponent
    }
];

//when we click on home, which will be a part of url, component mentioned will be rendered