import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { appRoutes } from './routerConfig';
import { RouterModule } from '@angular/router';
import { BannerComponent } from './banner/banner.component';
import { FilterComponent } from './filter/filter.component';
import { ListComponent } from './list/list.component';
import { BodyIndexComponent } from './body-index/body-index.component';
import { BodyContactComponent } from './body-contact/body-contact.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';
import { UserService } from './user.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BodyOffersComponent } from './body-offers/body-offers.component';
import { GridComponent } from './grid/grid.component';
import { BodyAboutComponent } from './body-about/body-about.component';
import { BodyDetailsComponent } from './body-details/body-details.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BannerComponent,
    FilterComponent,
    ListComponent,
    BodyIndexComponent,
    BodyContactComponent,
    BodyOffersComponent,
    GridComponent,
    BodyAboutComponent,
    BodyDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    Ng2SearchPipeModule,
    Ng2OrderModule,
    NgxPaginationModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
