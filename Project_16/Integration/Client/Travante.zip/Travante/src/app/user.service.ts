import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Injectable()
export class UserService {

  constructor(private http:HttpClient) { }
  baseUrl:string='http://localhost:8087/hotel_list/';//this is url at which you want to send request
  

  getUsers(){
  return this.http.get<any>(this.baseUrl);//this function willreturn obeservable

  }
  getDetails(id:number)
  {
    return this.http.get<any>(this.baseUrl+id);
  }
  
}
