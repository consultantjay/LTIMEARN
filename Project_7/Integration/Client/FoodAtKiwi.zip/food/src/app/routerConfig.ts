import {Routes} from '@angular/router';
import{FeaturedComponent} from './featured/featured.component';
import{ListingComponent} from './listing/listing.component';
import{AboutComponent} from './about/about.component';
import{ContactComponent} from './contact/contact.component';
import{AboutusComponent} from './aboutus/aboutus.component';
import{DetailComponent} from './detail/detail.component';
import { ListviewComponent } from './listview/listview.component';



export const appRoutes: Routes=[
{ path:'',
  component: FeaturedComponent

},
{ path:'Home',
  component: FeaturedComponent

},
{ path:'Restaurants',
  component: ListingComponent

},
{ path:'Contact',
  component: ContactComponent

},
{ path:'About',
  component: AboutusComponent

},
{ path:'Detail/:id',
  component: DetailComponent

},

{ path:'listview',
  component: ListviewComponent

},

{ path:'gridview',
  component: ListingComponent

}




];