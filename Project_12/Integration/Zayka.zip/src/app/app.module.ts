import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DataService } from './data.service';
import { Http, HttpModule, Response, Headers } from '@angular/http';
import { HttpHeaders } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxPaginationModule } from 'ngx-pagination';
// import {
//   MatButtonModule,
//   MatSelectModule,
//   MatCardModule,
//   MatCheckboxModule,
//   MatSlideToggleModule,
//   MatChipsModule,
// } from "@angular/material";
// import { MatTabsModule } from '@angular/material/tabs';

import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SearchComponent } from './search/search.component';
import { DetailsComponent } from './details/details.component';

const appRoutes: Routes = [
  {
    path: '',
    component: DashboardComponent
  },
  {
    path: 'search',
    component: SearchComponent
  },
  {
    path: 'details',
    component: DetailsComponent
  },
  {
    path: 'details/:address',
    component: DetailsComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    FooterComponent,
    SearchComponent, DetailsComponent
  ],
  imports: [
  	RouterModule.forRoot(appRoutes),
    BrowserModule,
    BrowserModule,
    BrowserAnimationsModule,
    // MatButtonModule,
    // MatTabsModule,
    // MatSelectModule,
    // MatCardModule,
    // MatChipsModule,
    // MatSlideToggleModule,
    // MatCheckboxModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    HttpModule
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
