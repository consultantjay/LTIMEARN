import { Component, OnInit } from '@angular/core';
import { FirstService } from 'services/first.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(private firstservice:FirstService, private router:Router){}
  product=[];
  ngOnInit(){
    this.firstservice.getProduct().subscribe(data=>{
      this.product=data
    })
  }
p:number=1

}
