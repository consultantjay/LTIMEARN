import { Component, OnInit,Input } from '@angular/core';
import { MapService } from 'src/app/services/map.service';
import { ViewJobComponent } from 'src/app/view-job/view-job.component';
import { Place } from 'src/entities/Places';
import { PlaceGeoLocation } from 'src/entities/PlaceGeoLoaction';

@Component({
  selector: 'app-map-component',
  templateUrl: './map-component.component.html',
  styleUrls: ['./map-component.component.css'],providers:[MapService]
})
export class MapComponentComponent implements OnInit {
    title: string = 'Map ';
    lat: number = 32.719569;
    lng: number = 79.857726;
    private geolocations:PlaceGeoLocation[]=[];
    private isMapComponentLoaded:boolean;

private loc=[{"lat":17.385044,"long":17.385044},{"lat":22.7195687,"long":22.7195687}];

private viewJobComponentRef:ViewJobComponent;



  constructor(private mapService:MapService) {
let object=this;
object.isMapComponentLoaded=false;
    this.getData();
   }

  ngOnInit() {
  }


@Input()
public set viewJobComponent(ref){
  let object=this;
  console.log('bbb');
   object.viewJobComponentRef=ref;
   object.viewJobComponentRef.setMapComponent(this);
}


public setPlaces(places){
let object=this;
object.geolocations=places;

console.log(object.geolocations);
  object.isMapComponentLoaded=true;
}

getData(){


let promise:Promise<any>=this.mapService.getLatLongs(null);

promise.then(function(response){
  console.log(response);
}).catch(function(error){
console.log(error);
});


}


}
