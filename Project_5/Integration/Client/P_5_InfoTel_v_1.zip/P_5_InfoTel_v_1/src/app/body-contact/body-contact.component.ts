import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body-contact',
  templateUrl: './body-contact.component.html',
  styleUrls: ['./body-contact.component.css']
})
export class BodyContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
