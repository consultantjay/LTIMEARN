// an async function to simulate loading an item from some server
function loadItem(id) {
    return new Promise((resolve) => {
        console.log('loading item', id);
        setTimeout(() => {
            resolve({ id: id });
        }, 1000);
    });
}
// Chaining
let item1, item2;
loadItem(1)
    .then((res) => {
    item1 = res;
    return loadItem(2);
})
    .then((res) => {
    item2 = res;
    console.log('done');
}); // overall time will be around 2s
// Parallel
Promise.all([loadItem(1), loadItem(2)])
    .then((res) => {
    [item1, item2] = res;
    console.log('done');
}); // overall time will be around 1s
