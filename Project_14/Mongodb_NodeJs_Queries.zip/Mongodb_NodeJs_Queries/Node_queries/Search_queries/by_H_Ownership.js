//Search by Hospital Ownership


var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"Hospital Ownership":"Government - Hospital District or Authority"
	    },function(err,res){
				console.log(res);
			       }
	   );