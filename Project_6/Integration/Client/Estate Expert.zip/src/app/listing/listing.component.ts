import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.css']
})
export class ListingComponent implements OnInit {

  //images=["assets/img/house1.jpg", "assets/img/house2.jpg", "assets/img/house3.jpg"];
  users=[];

  constructor(private userService: UserService) { }

  ngOnInit() {

    this.userService.getUsers()
    .subscribe(data => {
      this.users = data;
    });
  }
  p:number=1;
}
