import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
@Component({
  selector: 'app-body-offers',
  templateUrl: './body-offers.component.html',
  styleUrls: ['./body-offers.component.css']
})
export class BodyOffersComponent implements OnInit {

  hotels = [];
  constructor(private userService : UserService) {}

  ngOnInit() {
    this.userService.getUser().subscribe(data=> {
      this.hotels = data;
    });
  }
  p:number=1;
}
