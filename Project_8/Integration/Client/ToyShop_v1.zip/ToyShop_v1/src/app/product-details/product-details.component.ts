import { Component, OnInit } from '@angular/core';
import { FetchProductByIdService } from '../fetch-product-by-id.service'
import { Router, ActivatedRoute} from "@angular/router"


@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  eachToy = []
  constructor(private fetchProductByIdService: FetchProductByIdService, private router: Router,private activeRoute:ActivatedRoute) { }

  ngOnInit() {
    let id= this.activeRoute.snapshot.paramMap.get('uniq_id')
    this.fetchProductByIdService.getToyById(id)
    .subscribe(data=>{
      this.eachToy = data
    })
   
  }


  
}
