import { Component, OnInit } from '@angular/core';
import {UserService} from 'src/app/user.service';
import {ActivatedRoute} from '@angular/router'
@Component({
  selector: 'app-detail-banner',
  templateUrl: './detail-banner.component.html',
  styleUrls: ['./detail-banner.component.css']
})
export class DetailBannerComponent implements OnInit {

  detail=[];
  uniq_id: string;

  constructor(private activateRouter:ActivatedRoute, private userService:UserService) 
  {  let object = this;
     object.uniq_id = this.activateRouter.snapshot.paramMap.get('uniq_id');
    console.log(object.uniq_id);
  
  }

  
  ngOnInit() {
    console.log(this.uniq_id)
    this.userService.getDetails(this.uniq_id)
  .subscribe(data=>{
    console.log(data);
    this.detail = data;
    console.log(this.detail);
  })
}

}
