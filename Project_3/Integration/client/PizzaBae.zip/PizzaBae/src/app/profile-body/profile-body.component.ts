import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-profile-body',
  templateUrl: './profile-body.component.html',
  styleUrls: ['./profile-body.component.css']
})
export class ProfileBodyComponent implements OnInit {

  pizzaDetails = [];
  private restaurant_name:string;
// {
//       "_id" : "ObjectId(\"5b44b22014448a67f42c2c3e\")",
//       "id" : "AVwc_6KEIN2L1WUfrKAH",
//       "address" : "Cascade Village Mall Across From Target",
//       "city" : "Bend",
//       "country" : "US",
//       "latitude" : 44.10266476,
//       "longitude" : -121.3007971,
//       "menuPageURL" : "http://www.yellowpages.com/west-chester-pa/mip/country-bagel-bakery-451326037/menu",
//       "menus" : {
//               "amount" : 18.95,
//               "description" : "Olives, onions, capers, tomatoes",
//               "name" : "Cheese Pizza"
//       },
//       "name" : "Little Pizza Paradise",
//       "postalCode" : 97701,
//       "priceRangeMin" : 50,
//       "priceRangeMax" : 55,
//       "reviews" : 50,
//       "ratings" : 4
//}];
  // private restaurant_name:string;
  constructor(private activateRouter:ActivatedRoute,private userService:UserService){
    let object = this;
    object.restaurant_name = this.activateRouter.snapshot.paramMap.get('restaurant_name');
  }
  ngOnInit()
  {
    this.userService.getPizzaDetails(this.restaurant_name)
      .subscribe(data=>{
        console.log(data);
        this.pizzaDetails=data;
        console.log(this.pizzaDetails);
      });
  }

}
