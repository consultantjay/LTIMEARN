import { Component, OnInit } from '@angular/core';

import {Job} from '../../entities/job';


import {JobsService} from '../services/jobs.service';
import { FileUploadService } from 'src/app/services/file-upload.service';

import {SubQuery,Query} from '../../entities/Query';

import {ActivatedRoute} from '@angular/router';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';
import { Place } from 'src/entities/Places';
import { MapService } from 'src/app/services/map.service';
import { MapComponentComponent } from 'src/app/map-component/map-component.component';
import { PlaceGeoLocation } from 'src/entities/PlaceGeoLoaction';

/*
@author:Tarun Rawat
@Orgainzation:LTI
@Description:This componet will show info of selected job.

*/

@Component({
  selector: 'app-view-job',
  templateUrl: './view-job.component.html',
  styleUrls: ['./view-job.component.css'],providers:[FileUploadService,MapService]

})
export class ViewJobComponent implements OnInit {

  private selectedJob:Job;
  private jobId:number;
  private jobsLoaded:boolean;
  private selectedFile:FileList;
  private currentFile:File;
  private places:Place[]=[];//places array 
  private placesGeoLocations:PlaceGeoLocation[]=[];//each element will have location and lat,long of that location
  private mapComponent:MapComponentComponent;
  constructor(private activatedRouter:ActivatedRoute,private jobService:JobsService,private service:FileUploadService,private mapService:MapService) {
    this.jobsLoaded=false;
console.log('do baar');
  }

  ngOnInit() {
    this.setJob();
  }


public setJob(){
let object=this;
//This is way to get data from ActivatedRouter
object.jobId= parseInt(this.activatedRouter.snapshot.paramMap.get('jobid'));
object.getJob(this.jobId);
}


//This function will use service to get Job detail by Id
public getJob(jobId){
let object=this;
console.log('sending request for '+jobId);

let subQuery:SubQuery=new SubQuery();

subQuery.jobid=object.jobId;

let query:Query=new Query();
query.$match=subQuery;

let finalQuery=[];
finalQuery.push(query);

console.log(JSON.stringify(finalQuery));


let promise=object.jobService.getData(finalQuery);
//resolving promise
promise.then(function(response){

console.log(response);



if(response==[]) console.log('empty');


try{
  var json=JSON.parse(response);

}catch(error){
console.log(error);
}




let job:Job=new Job();

job.setJobId(json[0].jobid);
job.setJobtitle(json[0].jobtitle);
job.setJobDescription(json[0].jobdescription);
job.setSkills(json[0].skills);
job.setLocation(json[0].joblocation_address);
job.setCompanyName(json[0].company);
job.setPayScale(json[0].payrate);

object.selectedJob=job;
object.jobsLoaded=true;


object.setPlaces(object.selectedJob.getLocation());
}).catch(function(error){
  console.log('error');
console.log(error);

});

}

//This will user service function to get geocoding info of locations
setPlaces(places:string){
let object=this;

var data=places.split(",");//since there can be multiple places like Mumbai,Chennai,Ujjain,Indore so splitting it

data.forEach(function(x){
let place:Place=new Place();
place.location=x;
object.places.push(place);
})

//using service to get geocoding info
let promise:Promise<any>=object.mapService.getLatLongs(object.places);
promise.then(function(response){

  var data=JSON.parse(response);

for(let x of data){
let placeGeoLoaction:PlaceGeoLocation=new PlaceGeoLocation();

 placeGeoLoaction.place=x.value[0].city;
  placeGeoLoaction.lat=x.value[0].latitude;
  placeGeoLoaction.long=x.value[0].longitude;
 object.placesGeoLocations.push(placeGeoLoaction); 
}

object.mapComponent.setPlaces(object.placesGeoLocations);
//tranferring geocoding info to map component
}).catch(function(error){
  console.log(error);
});


}
//setting map component for child-parent communication
setMapComponent(ref){
let object=this;
object.mapComponent=ref;

}

//setting selected file
selectFile(event){
  console.log('chliii');
  this.selectedFile=event.target.files;
}


//This is used to upload file on server 
upload(){
this.currentFile= this.selectedFile.item(0);
this.service.pushFileToStorage(this.currentFile).subscribe(function(event) {
 if (event instanceof HttpResponse) {
    console.log('file uploaded');//work needs to be done
  }
});
this.selectedFile = undefined;


}

}
