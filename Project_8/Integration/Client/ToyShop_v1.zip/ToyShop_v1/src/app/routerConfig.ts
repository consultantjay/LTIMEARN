import {Routes,ActivatedRoute} from '@angular/router';

import { ShopComponent } from './shop/shop.component';
import { ProductDetailsComponent } from './product-details/product-details.component'
import { HomeComponent } from './home/home.component'
import { FooterComponent } from './footer/footer.component'
import { CartComponent } from './cart/cart.component'

export const appRoutes: Routes = [
    {
      path : '',
      component: HomeComponent
    },
    {
      path : 'home',
      component: HomeComponent
    },
    { path : 'shop',
      component: ShopComponent
    },
    { path : 'productDetails',
    component: ProductDetailsComponent
    },
    { path : 'productDetails/:uniq_id',
    component: ProductDetailsComponent
    },
    { path : 'cart',
      component: CartComponent
    }
];