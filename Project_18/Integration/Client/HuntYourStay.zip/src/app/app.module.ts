import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//import { AppComponent } from './app.component';
//import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import {appRoutes} from './routerConfig';
import {RouterModule} from '@angular/router';
import {AppComponent} from './app.component';
import {HeaderComponent} from './header/header.component';
import { HomeBannerComponent } from './home-banner/home-banner.component';
import { ListingBannerComponent } from './listing-banner/listing-banner.component';
import {APP_BASE_HREF} from '@angular/common';
import { GridViewBannerComponent } from './grid-view-banner/grid-view-banner.component';
import { AboutBannerComponent } from './about-banner/about-banner.component';
import { ContactBannerComponent } from './contact-banner/contact-banner.component';
import { DetailBannerComponent } from './detail-banner/detail-banner.component';
//import { BrowserModule } from '@angular/platform-browser';
//import { NgModule } from '@angular/core';
import {Ng2SearchPipeModule, Ng2SearchPipe} from 'ng2-search-filter';
import {Ng2OrderModule} from 'ng2-order-pipe';
//import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination';
import {UserService} from './user.service';
import {HttpClientModule} from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeBannerComponent,
    ListingBannerComponent,
    GridViewBannerComponent,
    AboutBannerComponent,
    ContactBannerComponent,
    DetailBannerComponent
  ],
  imports: [
    BrowserModule,
   RouterModule.forRoot(appRoutes),
  
   Ng2SearchPipeModule,
   FormsModule,
   Ng2OrderModule,
   NgxPaginationModule,
   HttpClientModule
  ],
  providers: [UserService,{provide: APP_BASE_HREF, useValue:'/'}],
  bootstrap: [AppComponent]
})
export class AppModule { }
