import { Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomebodyComponent } from './homebody/homebody.component';
import { SearchbodyComponent } from './searchbody/searchbody.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
export const appRoutes: Routes = [

    { path:'',
      component:HomebodyComponent 
    },
    { path:'home',
      component:HomebodyComponent 
    },
    { path:'search',
      component:SearchbodyComponent 
    },
    { path:'header',
    component:HeaderComponent 
    },
    { path:'footer',
    component:FooterComponent 
    },
    { path:'details/:pid/:image_id',
    component:ProductDetailComponent 
    },
]; 