import { Injectable } from '@angular/core';


/*
@Author:Tarun Rawat
@Version:1.0.0
@Description:This service is main service which fetch geocoding info of the giving locations.
             This service uses promises to fetch data   

*/


@Injectable({
  providedIn: 'root'
})

export class MapService {

  constructor() { }


public getLatLongs(places):Promise<any>{


let assurance:Promise<any>=new Promise<any>(function(resolve,reject){

let request=new XMLHttpRequest();

request.onload=function(){

if(request.status==200){
resolve(request.response);
}else{
reject(new Error("Cannot fetch data"));
}

};

request.onerror=function(){
reject(new Error("Error in map"));
}

let url='/JobsPortal/getGeoLocation';

request.open("POST",url);
request.send(JSON.stringify(places));


});



  return assurance;
}


}
