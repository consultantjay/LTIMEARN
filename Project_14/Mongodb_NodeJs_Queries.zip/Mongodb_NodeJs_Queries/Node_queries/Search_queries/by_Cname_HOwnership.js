// Search by City and Hospital ownership

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"City":"HAMILTON",
		"Hospital Ownership":"Voluntary non-profit - Private"
	    },function(err,res){
				console.log(res);
			       }
	   );