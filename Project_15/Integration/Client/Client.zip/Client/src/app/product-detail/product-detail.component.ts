import { Component, OnInit } from '@angular/core';
import{ UserService } from '../user.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
   pid : string;
  image_id : number;
  constructor(private productdetailservice:UserService,private activatedRoute:ActivatedRoute) { 
    let object=this;
    object.pid=this.activatedRoute.snapshot.paramMap.get('pid');
    object.image_id=parseInt(this.activatedRoute.snapshot.paramMap.get('image_id'));
  }
  images = ['parallax_slider_03.jpg','single_hotel_01.png','single_hotel_02.png','single_hotel_03.png',
  'single_hotel_04.png','hotel_08.png'] ;
  ngOnInit() {
    this.getProductPage(this.pid);
  }
  productDetails = {};
  getProductPage(pid:string)
{ 
 
    this.productdetailservice.getProductDetails(this.pid)
    .subscribe(data => 
    { 
      this.productDetails = data[0];
    });
    }
}
