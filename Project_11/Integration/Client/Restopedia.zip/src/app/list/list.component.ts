import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})

export class ListComponent implements OnInit {
  restaurants= [];
  constructor(private userService : UserService){}
  ngOnInit(){
    this.userService.getUser().subscribe(data=> {
      this.restaurants = data;
      console.log(this.restaurants);
    });
  }
  key:string = 'Name';
  reverse:boolean = false;
  sort(key){
    this.key = key;
    this.reverse = !this.reverse;
  }
  p:number = 1;

}
