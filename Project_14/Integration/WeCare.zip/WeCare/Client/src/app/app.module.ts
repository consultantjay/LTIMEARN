import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { appRoutes } from './routerConfig';
import { RouterModule } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
import { ContentComponent } from './content/content.component';
import { ListComponent } from './list/list.component';
import { HospitalServiceService } from 'src/app/hospital-service.service';
import { HttpClientModule } from "@angular/common/http";
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { FormsModule } from '@angular/forms';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';
import { DetailComponent } from './detail/detail.component';
import { BannerComponent } from './banner/banner.component';




@NgModule({
  declarations: [
    AppComponent,
    ContentComponent, 
    ListComponent,
    HeaderComponent,
    FooterComponent,
    DetailComponent,
    BannerComponent
  ],

  imports: [
    Ng2SearchPipeModule,
    Ng2OrderModule,
    NgxPaginationModule,
    HttpClientModule,
    BrowserModule, 
    RouterModule.forRoot(appRoutes),
    FormsModule
  ],

  providers: [HospitalServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
