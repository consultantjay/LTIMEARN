import { Component, OnInit } from '@angular/core';
import { FetchAllService } from '../fetch-all.service'
import { Router, ActivatedRoute} from "@angular/router"

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  toysHomeGridAll = []
  constructor(private fetchAllService : FetchAllService, private router: Router) { }

 
  ngOnInit() {
  
    this.fetchAllService.getToysHomeGrid()
    .subscribe(data=>{
      this.toysHomeGridAll = data
    })
  }

}
