import React from 'react';

export class ListItem extends React.Component{
    
    render(){
        return(
            <li>
            <h4>Listing of Recs</h4>
          </li>
        );
    }
}