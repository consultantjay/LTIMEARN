import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact2',
  templateUrl: './contact2.component.html',
  styleUrls: ['./contact2.component.css']
})
export class Contact2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
