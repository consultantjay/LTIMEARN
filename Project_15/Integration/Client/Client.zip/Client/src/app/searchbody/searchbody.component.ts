import { Component, OnInit } from '@angular/core';
import{ UserService } from '../user.service'
import { NgForm } from '@angular/forms';
import { HeaderComponent } from 'src/app/header/header.component';

@Component({
  selector: 'app-searchbody',
  templateUrl: './searchbody.component.html',
  styleUrls: ['./searchbody.component.css']
})
export class SearchbodyComponent implements OnInit {
  
  //TODO -Declaration of variables used in search page
  users = [];
  name="";
  city ="";
  area ="";
  hotel_name ="";
  searched_data="";
  hotel_category="";
  p:number=1;

  //TODO- Decalartion of Service
  constructor(private userService:UserService){}
  ngOnInit(){
    this.userService.getList() //TODO - Get list of all the resorts in dataset
    .subscribe(data => {
          this.users = data;
    });
    window.scrollTo(0, 0)
  }
  //TODO - Sort by rating 
  key:string = 'City';
  reverse:boolean = false;
  sort(key){
    this.key = key;
    this.reverse = !this.reverse;
  }
  //TODO -Array of images
  images = [
    'parallax_slider_03.jpg',
    'single_hotel_01.png',
    'single_hotel_02.png',
    'single_hotel_03.png',
    'single_hotel_04.png',
    'hotel_08.png'
  ] ;
  //TODO - To print star
  printStar(number){
    var items: number[] = [];
    for(var i = 1; i <= number; i++){
       items.push(i);
    } 
    return items;
  }
  printLeftStar(number){
    var restvalue = 5-number;
    var itemsstar: number[] = [];
    for(var i = 1; i <= restvalue; i++){
    itemsstar.push(i);
    }
    return itemsstar;
  }
  //TODO - Get data of search (by city name, hotel name and area)
  searchData(form:NgForm){
    this.city= form.value.city;
    this.area= form.value.area;
    this.hotel_name= form.value.hotelname;

    //TODO get data through city
    if(this.city!=="" && this.area=="" && this.hotel_name==""){
      this.userService.getResortByCity(this.city)
      .subscribe(data => {
       this.users = data;
      }); 
    }
    //TODO get data through area
    else if(this.city=="" && this.area!=="" && this.hotel_name==""){
      this.userService.getResortByArea(this.area)
      .subscribe(data => {
        this.users = data;      
      }); 
    }
    //TODO get data through hotel name
    else if(this.city=="" && this.area=="" && this.hotel_name!==""){
      this.userService.getResortByHotelName(this.hotel_name)
      .subscribe(data => {
        this.users = data;
      }); 
    }
    //TODO get data through city and area
    else if(this.city!=="" && this.area!=="" && this.hotel_name==""){
      this.userService.getResortsByCityArea(this.city,this.area)
      .subscribe(data => {
        this.users = data;
      }); 
    }
    //TODO get data through city and hotel name
    else if(this.city!=="" && this.area=="" && this.hotel_name!==""){
      this.userService.getResortsByCityHotelName(this.city,this.hotel_name)
      .subscribe(data => {
        this.users = data;
      }); 
    }
    //TODO get data through area and hotel name
    else if(this.city=="" && this.area!=="" && this.hotel_name!==""){
      this.userService.getResortsByAreaHotelName(this.area,this.hotel_name)
      .subscribe(data => {
        this.users = data;
      }); 
    }
    //TODO get data through city, area and hotel name
    else if(this.city!=="" && this.area!=="" && this.hotel_name!==""){
      this.userService.getResortsByCityAreaHotelName(this.city,this.area,this.hotel_name)
      .subscribe(data => {
        this.users = data;
      }); 
    }
    //TODO get data where city, area and hotel name are blank
    else if(this.city=="" && this.area=="" && this.hotel_name==""){
      this.userService.getList()
      .subscribe(data => {
        this.users = data;
      }); 
    }
    this.city=""
    this.area=""
    this.hotel_name=""
  }
}

