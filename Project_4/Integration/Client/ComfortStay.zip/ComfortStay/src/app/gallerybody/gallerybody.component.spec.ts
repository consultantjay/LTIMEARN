import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GallerybodyComponent } from './gallerybody.component';

describe('GallerybodyComponent', () => {
  let component: GallerybodyComponent;
  let fixture: ComponentFixture<GallerybodyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GallerybodyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GallerybodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
