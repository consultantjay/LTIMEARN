import { Routes } from '@angular/router';
import { ContactComponent } from './contact/contact.component';
import { ListingComponent } from './listing/listing.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { SingleListingComponent } from './single-listing/single-listing.component';
import { GridviewComponent } from './gridview/gridview.component'
export const appRoutes: Routes=[
   {path:'contact',
    component:ContactComponent
   },
   {path:'listing',
   component:ListingComponent 
   },
   {path:'',
   component:HomeComponent 
   },
   {path:'home',
   component:HomeComponent 
   },
   {path:'about',
   component:AboutComponent 
   },
   {path:'single-listing/:id',
   component:SingleListingComponent 
   },
   {path:'grid-view',
   component:GridviewComponent 
   }
];