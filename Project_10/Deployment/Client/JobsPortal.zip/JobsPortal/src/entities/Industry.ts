export class Industry{
  name:string;
}
