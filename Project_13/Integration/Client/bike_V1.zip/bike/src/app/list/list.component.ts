import { Component, OnInit } from '@angular/core';
import { BikeService } from '../bike.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  bikes=[];
  images =['bike(1)','bike(2)','bike(3)','bike(4)','bike(5)','bike(6)','bike(7)','bike(8)','bike(9)'];
  constructor(private bikeService:BikeService) { }
  ngOnInit()
  {
    this.bikeService.getbikes()
    .subscribe( data=> 
      { this.bikes=data;
      }
    );
  }
  
  /*key:string='Make';
  reverse:boolean=false;
  sort(key)
  {
    this.key=key;
    this.reverse=!this.reverse;
  }*/
  p:number=1;

}
