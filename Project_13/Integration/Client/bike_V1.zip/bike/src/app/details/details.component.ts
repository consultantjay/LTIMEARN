import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BikeService } from '../bike.service';
import { Bike } from '../entities/bike'

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  private uid:number;
  private bike:Bike;
  isBikeLoaded:boolean;
  images =['bike(1)','bike(2)','bike(3)','bike(4)','bike(5)','bike(6)','bike(7)','bike(8)','bike(9)'];
  constructor(private activatedRouter:ActivatedRoute,private bikeService:BikeService) 
  {
    let object=this;
    object.uid=parseInt(this.activatedRouter.snapshot.paramMap.get('uid'));
    object.isBikeLoaded=false;
  }
  make;
  ngOnInit()
  { let object=this;
    this.bikeService.getBikeById(this.uid)
    .subscribe( data=> 
      { var data1=data[0];
        let ubike:Bike=new Bike();      
        ubike.setUid(data1.uid);
        ubike.setCondition(data1.Condition);
        ubike.setMake(data1.Make);
        ubike.setLocat(data1.Location);
        ubike.setModel(data1.Model);
        ubike.setMileage(data1.Mileage);
        ubike.setPrice(data1.Price);
        ubike.setWarranty(data1.Warranty);
        ubike.setModel_Year(data1.Model_Year);
        ubike.setN_Reviews(data1.N_Reviews);
        ubike.setFeedback_Perc(data1.Feedback_Perc);
        ubike.setExterior_Color(data1.Exterior_Color);
        ubike.setSub_Model(data1.Sub_Model);
        ubike.setType(data1.Type);
        ubike.setSeller_Status(data1.Seller_Status);
        object.bike=ubike;
        object.isBikeLoaded=true;
        //set bike loaded true
      }
    );
    }
}

