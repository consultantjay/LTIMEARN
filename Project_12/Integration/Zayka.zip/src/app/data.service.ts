import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';

@Injectable()
export class DataService {

  private log = "/api/login";
  private fetchCountry = "/api/country";
  private fetchCity = "/api/city";
  private fetchSpecCity = "/api/city/";
  private fetchRestsCountry = "/api/country/Zomato/";
  private fetchRestsCity = "/api/city/Zomato/";
  private fetchRestsCountity = "/api/countity/Zomato/";
  private fetchRestsName = "/api/name/Zomato/";
  private fetchRestsCountryName = "/api/countryname/Zomato/";
  private fetchRestsCityName = "/api/cityname/Zomato/";
  private fetchRestsCountityName = "/api/countityname/Zomato/";
  private fetchRestsDelivery = "/api/delivery/Zomato/";
  private fetchRestsCuisine = "/api/cuisine/Zomato/";
  private fetchRestsaddr ='/api/Address/';

  constructor(private http: Http) {
  }

  login(k:any) {
  	var headersForTokenApi = new Headers({'Content-Type': 'application/json'});
  	let body =JSON.stringify(k);
  	var url = this.log;
    return this.http.post(url, body, {headers: headersForTokenApi}).map(response => response.text() ? response.json() : response);
  }

  getCurrentIpLocation() {
        return this.http.get('http://ipinfo.io')
        .map(response => response.json())
        .catch(error => {
            console.log(error);
            return Observable.throw(error.json());
        });
    }

  getCountry() {
    var url = this.fetchCountry;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getCity() {
  	var url = this.fetchCity;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getSpecCity(country: any) {
    var url = this.fetchSpecCity + country;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsCountry(country: any) {
    var url = this.fetchRestsCountry + country;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsCity(city: any) {
    var url = this.fetchRestsCity + city;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsCountity(city: any, country: any) {
    var url = this.fetchRestsCountity + city + '/' + country;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsName(name: any) {
    var url = this.fetchRestsName + name;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsCountryName(country: any, name: any) {
    var url = this.fetchRestsCountryName + country  + '/' + name;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsCityName(city: any, name: any) {
    var url = this.fetchRestsCityName + city + '/' + name;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsCountityName(city: any, country: any, name: any) {
    var url = this.fetchRestsCountityName + city + '/' + country + '/' + name;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsDelivery(city: any, country: any) {
    var url = this.fetchRestsDelivery + city + '/' + country;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsCuisine(city: any, country: any, name: any) {
    var url = this.fetchRestsCuisine + city + '/' + country + '/' + name;
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

  getRestsaddr(addr: any) {
    var url = this.fetchRestsaddr + addr; //private fetchRestsaddr ='/api/Address/';
    return this.http.get(url)
    .map(response => response.text() ? response.json() : response)
  }

}
