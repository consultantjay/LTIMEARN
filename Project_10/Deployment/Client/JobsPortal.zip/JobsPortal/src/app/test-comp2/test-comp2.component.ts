import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-test-comp2',
  templateUrl: './test-comp2.component.html',
  styleUrls: ['./test-comp2.component.css']
})
//This class is for testing purpose and has nothing to do with project
export class TestComp2Component implements OnInit {

  private name:string="Tarun"

  private isloaded:boolean=false;
    constructor() {

console.log('test comp2');
     }
  ngOnInit() {
  }

}
