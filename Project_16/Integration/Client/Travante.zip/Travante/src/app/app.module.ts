import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import{ appRoutes} from './routerConfig';

// import{RouterModule} from '@angular/routes';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { FrontPageComponent } from './front-page/front-page.component';
import {Routes,RouterModule} from '@angular/router';
import { SearchComponent } from 'src/app/search/search.component';
import { CombineComponent } from './combine/combine.component';
import { ListComponent } from './list/list.component';
import { UserService } from './user.service';
import { HttpClientModule } from '@angular/common/http';
import { GridComponent } from './grid/grid.component';
import { DetailComponent } from './detail/detail.component';

const routes:Routes=[{path:'search',component:SearchComponent},{path:'list',component:ListComponent},{path:'',component:FrontPageComponent},{path:'grid',component:GridComponent},{path:'detail/:id',component:DetailComponent}];




@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    FrontPageComponent,SearchComponent, CombineComponent, ListComponent, GridComponent, DetailComponent,
    
  ],

  
  imports: [
    BrowserModule,
   RouterModule.forRoot(routes),
     HttpClientModule
   ],
   providers: [UserService],
     

  bootstrap: [AppComponent]
})
export class AppModule { }
