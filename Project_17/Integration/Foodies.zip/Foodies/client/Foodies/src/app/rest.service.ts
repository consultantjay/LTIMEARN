import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';


@Injectable()
export class RestService {

  constructor(private http:HttpClient) { }
  baseUrl:string='http://localhost:3000/'
  getRests(){
    return this.http.get<any>(this.baseUrl);
  }
  homeRests(){
    return this.http.get<any>(this.baseUrl+"home");
  }
  
  getDetails(id:number)
  {
    return this.http.get<any>(this.baseUrl+id);
  }

  saveUser(name:string,subject:string,email:string,message:string){      
    return this.http.get(this.baseUrl+'SaveUser/'+ name+'/'+subject+'/'+email+'/'+message) ; 
       
          } 

    //get name of all cities of particular country        
  getCity(country:string){
    return this.http.get<any>(this.baseUrl+"getcity/"+country);
  }


    //get name of all restaurants of particular city    
  getRest(country:string,city:string){
    return this.http.get<any>(this.baseUrl+"getRest/"+country+"/"+city);
  }


  //services for data according to user selection

  getCountryData(country:string){
    return this.http.get<any>(this.baseUrl+"getCountryData/"+country);
  }

  getCountryCityData(country:string,city:string){
    return this.http.get<any>(this.baseUrl+"getCountryCityData/"+country+"/"+city);
  }

  getCountryCityRestData(country:string,city:string,restaurant:string){
    return this.http.get<any>(this.baseUrl+"getCountryCityRestData/"+country+"/"+city+"/"+restaurant);
  }


}
