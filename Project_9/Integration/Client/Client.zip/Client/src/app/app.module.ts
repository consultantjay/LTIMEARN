import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';

import { ProductComponent } from './product/product.component';
import { ContactComponent } from './contact/contact.component';
import {appRoutes} from './routerConfig'
import { RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { FirstService } from 'services/first.service';
import { HttpClientModule } from '@angular/common/http';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {Ng2SearchPipeModule} from 'ng2-search-filter'
import {FormsModule} from '@angular/forms'
import {NgxPaginationModule} from 'ngx-pagination';
import { ProductCategoryComponent } from './product-category/product-category.component'
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ProductComponent,
    ContactComponent,
    AboutComponent,
    ProductDetailComponent,
    ProductCategoryComponent,
  
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(appRoutes),HttpClientModule,FormsModule,Ng2SearchPipeModule,NgxPaginationModule
  ],
  providers: [FirstService],
  bootstrap: [AppComponent]
})
export class AppModule { }
