import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { Ng2SearchPipeModule } from 'ng2-search-filter'
import { FormsModule } from '@angular/forms'
import { Ng2OrderModule } from 'ng2-order-pipe'
import { NgxPaginationModule } from 'ngx-pagination'

import { HttpClientModule } from '@angular/common/http';
import { BikeService } from './bike.service';

import { appRoutes } from './routerConfig';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HomebodyComponent } from './homebody/homebody.component';
import { DetailsComponent } from './details/details.component';
import { ListComponent } from './list/list.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    HomebodyComponent,
    DetailsComponent,
    ListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    Ng2OrderModule,
    NgxPaginationModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [BikeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
