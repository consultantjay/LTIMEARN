import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {
  hotels=[];

  constructor(private userService:UserService) { }

   ngOnInit(){
    this.userService.getUsers()
    .subscribe(data=>{
      this.hotels=data;
    })
  }
  }
  