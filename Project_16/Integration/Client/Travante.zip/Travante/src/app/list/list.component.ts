import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service'; 


@Component({//This is decorator like mateadata like annotation
  selector: 'app-list',//this is tag
  templateUrl: './list.component.html',//html file or view that is associated with this component
  styleUrls: ['./list.component.css']// css file associated with this component
})
export class ListComponent implements OnInit {
hotels=[];


constructor(private userService:UserService){ //injection of userservice
  
  this.userService.getUsers().subscribe(data=>{//this is resolving of observable 
    this.hotels=data;//this is where u get final data
    console.log(data);
  })

}
ngOnInit(){
  this.userService.getUsers().subscribe(data=>{//this is resolving of observable 
    this.hotels=data;//this is where u get final data
    console.log(data);
  })
}
}
