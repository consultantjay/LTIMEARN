import {Routes} from '@angular/router';
import { BodyIndexComponent } from './body-index/body-index.component';
import { BodyOffersComponent } from 'src/app/body-offers/body-offers.component';
import { BodyContactComponent } from 'src/app/body-contact/body-contact.component';
import { BodyAboutComponent } from 'src/app/body-about/body-about.component';
import { GridComponent } from 'src/app/grid/grid.component';
import { BodyDetailsComponent } from 'src/app/body-details/body-details.component';



export const appRoutes: Routes = [
	{ 
		path: '',
	component: BodyIndexComponent
	},{
		path: 'offers',
		component: BodyOffersComponent
		},
	{
		path: 'home',
		component: BodyIndexComponent
	},
	{
		path: 'contact',
		component: BodyContactComponent
	},
	{
		path: 'about',
		component: BodyAboutComponent
	},
	{
		path: 'grid',
		component: GridComponent
	},
	{
		path: 'detail/:id',
		component: BodyDetailsComponent
	}					
]