// Search by State

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		State:"AZ"
	    },function(err,res){
				console.log(res);
			       }
	   );