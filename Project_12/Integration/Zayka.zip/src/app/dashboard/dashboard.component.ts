import { Component, OnInit, ElementRef, ViewChild, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { DataService } from '../data.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  userImg: string;
  myLists = [];
  @ViewChild('myId') myId;
  @ViewChild('city') city;
  @ViewChild('fetch') fetch;

  constructor(private router:Router, private dataService:DataService, private activeRoute: ActivatedRoute) {
  	this.userImg = '/assets/images/user.png';
  	this.dataService.getCurrentIpLocation()
	      .subscribe(
	            data => {
	            	this.city.nativeElement.value = data.city;
	            }
	        );
    setTimeout(()=>{
    	this.fetch.nativeElement.click();
    }, 2000);
  }

  ngOnInit() {
  	this.fetchValues();
  }

  fetchValues() {
  	this.myLists = [];
  	if(this.city.nativeElement.value!='') {
  		this.dataService.getRestsCity(this.city.nativeElement.value)
	      .subscribe(
	            data => {
	            	this.myLists = data.data.splice(0,6);

	            }
	        );
  	}
  }

  search() {
  	this.router.navigate(['/search']);
  }

}
