import { Component } from '@angular/core';
import { HospitalServiceService } from 'src/app/hospital-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


/*key : string = 'Hospital Name'; //set default
reverse  :  boolean = false;
sort(key){
this.key=key;
this.reverse = !this.reverse;
}
*/

//initializing p to one
/*p: number = 1;*/
  
}
