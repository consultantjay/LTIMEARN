// Search by City and State

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"City":"KAMUELA",
		State:"HI"
	    },function(err,res){
				console.log(res);
			       }
	   );