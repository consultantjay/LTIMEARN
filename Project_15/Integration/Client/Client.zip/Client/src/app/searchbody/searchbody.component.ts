import { Component, OnInit } from '@angular/core';
import{ UserService } from '../user.service'
@Component({
  selector: 'app-searchbody',
  templateUrl: './searchbody.component.html',
  styleUrls: ['./searchbody.component.css']
})
export class SearchbodyComponent implements OnInit {
  users = [];
  constructor(private userService:UserService){}
  ngOnInit(){
        this.userService.getUsers()
        .subscribe(data => {
              this.users = data;
        });
  }
  key:string = 'City';
  reverse:boolean = false;
  sort(key){
    this.key = key;
    this.reverse = !this.reverse;
  }
  p:number=1;
  images = ['parallax_slider_03.jpg','single_hotel_01.png','single_hotel_02.png','single_hotel_03.png',
  'single_hotel_04.png','hotel_08.png'] ;
  createRange(number){
    var items: number[] = [];
    for(var i = 1; i <= number; i++){
       items.push(i);
    } 
    return items;
  }
  createBlank(number){
    var restvalue = 5-number;
    var itemsstar: number[] = [];
    for(var i = 1; i <= restvalue; i++){
    itemsstar.push(i);
    }
    return itemsstar;
  }
}
