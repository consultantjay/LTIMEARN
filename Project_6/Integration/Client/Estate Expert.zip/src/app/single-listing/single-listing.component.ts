import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/user.service';



@Component({
  selector: 'app-single-listing',
  templateUrl: './single-listing.component.html',
  styleUrls: ['./single-listing.component.css']
})
export class SingleListingComponent implements OnInit {
    detail=[];
    private uid:number;
    constructor(private activateRouter:ActivatedRoute, private userService:UserService){
      let object=this;
      object.uid=parseInt(this.activateRouter.snapshot.paramMap.get('id'));
      console.log(object.uid);

    }
    ngOnInit() {
      console.log(this.uid)
      this.userService.getDetails(this.uid)
      .subscribe( data => {
        console.log(data);
        this.detail=data;
      })
   
}}
