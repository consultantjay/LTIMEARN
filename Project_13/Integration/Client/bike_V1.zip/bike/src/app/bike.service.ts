import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Bike } from '../app/entities/bike'

@Injectable({
  providedIn: 'root'
})
export class BikeService {

  constructor(private http:HttpClient) { }
  baseUrl:string='http://localhost:3000/';
  getbikes()
  {
    return this.http.get<any>(this.baseUrl);
  }
  getBikeById(id:number):Observable<any>
  {
    return this.http.get(this.baseUrl+id);
  }
}
