// Search by Hospital Name and State

var mongojs=require('mongojs');
var db=mongojs('P',['hos']);
db.hos.find({
		"Hospital Name":"MANCHESTER MEMORIAL HOSPITAL",
		State:"CT"
	    },function(err,res){
				console.log(res);
	       		       }
           );