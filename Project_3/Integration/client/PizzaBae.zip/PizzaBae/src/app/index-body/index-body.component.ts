import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index-body',
  templateUrl: './index-body.component.html',
  styleUrls: ['./index-body.component.css']
})
export class IndexBodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
